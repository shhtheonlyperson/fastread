# Handoff: JustRead — iOS Speed Reader

## Overview
JustRead is an iOS speed-reading app. It presents text one word at a time (RSVP — Rapid Serial Visual Presentation) with a *focus letter* highlighted in a fixed visual position so the reader's eyes can stay still while prose moves through. The aesthetic is editorial and warm: cream "paper" background, terracotta accent, Fraunces serif headlines.

The product has six surfaces:
1. **Library (Home)** — masthead, today's stats, continue-reading hero, list of articles
2. **Add (Source)** — paste text or fetch a URL
3. **Reader** — RSVP one-word view with transport (play/pause, scrub, pace)
4. **Focus mode** — fullscreen, dark, distraction-free version of Reader
5. **Stats** — words read, streak, weekly bar chart
6. **Settings** — pace, punctuation pause, focus indicator, word typeface

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing intended look and behavior, not production code to copy directly. Your task is to **recreate these designs in the target codebase's environment** (SwiftUI for native iOS, React Native, or whatever the project uses). If no environment exists yet, choose the most appropriate framework — for an iOS app this almost certainly means SwiftUI.

The HTML prototype includes a working RSVP engine (tokenizing, focus-letter math, per-word duration with punctuation pauses) — port the *logic*, not the JS, into the target language.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, and interactions are all set. Recreate pixel-perfectly using the codebase's existing libraries and patterns.

## Design Tokens

### Color
| Token | Hex | Use |
|---|---|---|
| `paper` | `#f5efe2` | App background (warm cream) |
| `paper-strong` | `#faf6ec` | Card / elevated surfaces |
| `paper-deep` | `#ece4d2` | Pressed / sunken surfaces |
| `ink` | `#1f1a17` | Primary text |
| `ink-mid` | `#4a3f37` | Secondary text |
| `ink-quiet` | `#8a7a6a` | Tertiary text, labels, meta |
| `rule` | `rgba(31,26,23,0.08)` | Hairline dividers |
| `rule-strong` | `rgba(31,26,23,0.18)` | Stronger dividers |
| `terracotta` | `#c96442` | The single accent — focus letter, active tab, primary CTA, progress fill |

The terracotta is the **only** chromatic color — it's reserved for moments of focus and meaning. Everything else is in the warm cream/ink range. Resist the urge to add other accent colors.

### Type
- **Serif** — `Fraunces` (Google Fonts; opsz 9..144, weights 400/500/600/700). Used for all titles, hero numbers, the RSVP word itself when set to "serif", and the wordmark.
- **Sans** — `Inter` (weights 400/500/600/700). Used for body copy, meta, UI labels.
- **Mono** — `JetBrains Mono` (weights 400/500). Used for SECTION LABELS (uppercase, tracked 0.14em) and small numeric values.

When porting to iOS native: Fraunces and Inter are both available as variable fonts; bundle them. Or substitute Fraunces → New York (system serif) and Inter → SF Pro if you must avoid bundled fonts, but the editorial feel will weaken.

### Spacing & Radii
- Card radius: `4px` (deliberately small — newsprint feel, not soft-iOS rounded)
- App icon radius: `~22.5%` of icon size (standard iOS squircle)
- Tab bar buttons: `13px` radius
- Hairlines: `0.5px solid var(--rule)` for card borders
- Button thumbs (sliders): 18px diameter, terracotta, soft shadow

### Section Labels
Repeating motif throughout: small uppercase mono labels (11px, 0.14em letter-spacing, `ink-quiet` color) acting as headers above content groups. Examples: "CONTINUE READING", "TODAY", "VOL. 47 · FRI". This is a load-bearing pattern — keep it.

## Brand Mark / App Icon
The icon is a custom letter-mark on cream paper:
- Cream gradient background (160deg, `#f3ece1` → `#e9dcc5` → `#d9c8aa`)
- Subtle horizontal paper grain (repeating linear gradient at ~3% black, 7px stripes)
- **J** in sans-serif (Inter, weight 500, 0.55 ink opacity, scaled to 0.92em so its cap height is just below the R), edge-to-edge with R
- **R** in serif (Fraunces, weight 700, terracotta `#c96442`)
- A small terracotta **focus dot** sitting at the top-right of the letter group (size: 11% of icon size, offset right -14%, top 6%)

The dot is the visual hook — it represents the RSVP focus letter and ties the icon to the app's core mechanic. Reproduce this faithfully.

## Screens

### 1. Library (Home)
**Purpose:** Daily landing — see today's reading stats, resume the article in progress, browse the queue.

**Layout (top to bottom, 390pt-wide iPhone):**
- **Masthead** (60pt top inset, 24pt horizontal padding):
  - Row: 28pt JustRead icon + "JustRead" wordmark (serif 19, weight 600) on left; "VOL. 47 · FRI" section label on right
  - Hero block: "Today you've read [N] words." set in serif 38pt, weight 500, letter-spacing -1, line-height 1.02. The number is in terracotta. Below: "[N] minutes across [N] articles. Streak: [N] days." in sans 14, `ink-quiet`.
- **Continue-reading card** (16pt horizontal padding):
  - `paper-strong` background, 4pt radius, 0.5px `rule` border, 18pt padding
  - "CONTINUE READING" label on left + "[N] of [N]" word count in terracotta on right
  - Article title in serif 22pt, weight 500
  - Progress bar: 2pt tall, `rule` track, terracotta fill at current %; "34%" in mono 11 to the right
  - Source · read time on left; right caret on right
- **Article list** — each row: source label, serif title (18pt), lede (sans 13, `ink-mid`), tag pill (Reading now / Saved / Finished). Hairline rule between rows.

**Components:** TabBar (bottom, see below), SectionLabel, Card (paper-strong + rule border), ProgressBar.

### 2. Add (Source)
**Purpose:** Get text into the reader.

**Layout:**
- Masthead: "Add to library" serif 32pt + "Paste text or fetch a URL" sans 14
- Two big tap targets: paste-from-clipboard, paste URL
- Below: large textarea for direct paste; primary "Start reading" button (terracotta) appears when textarea has content

### 3. Reader
**Purpose:** The core RSVP experience. Reading happens here.

**Layout:**
- Top bar: back chevron, source · read-time meta, expand-to-focus icon
- Article context strip: title (serif 17, 1 line truncated) + author · date
- **Word stage** — the centerpiece. Vertically centered, takes ~50% of vertical space:
  - Three spans rendered with the focus letter at a fixed horizontal position (use `RSVPCore.splitForFocus(token)` — see below)
  - Word set in the chosen typeface at ~44pt
  - Focus letter in terracotta, identical position regardless of word length
  - Focus indicator (dot/line/crosshair, see Settings) marks the column above and below the focus letter
- Transport row: scrubber (current word index / total), elapsed/remaining
- Big play/pause button (centered, terracotta when paused, ink when playing — or vice versa)
- Pace strip: words-per-minute readout + slider (150–1000, step 25)

### 4. Focus Mode
**Purpose:** Fullscreen distraction-free reader.

Same word stage as Reader, but:
- Background flips to near-black (`#1a1611` or similar warm-dark)
- Paper text becomes cream
- Terracotta focus letter stays terracotta (it pops more on dark)
- All chrome (tab bar, transport meta) disappears; only the word, focus indicator, and a small dismiss target in the corner remain
- Tap anywhere → pause; tap dismiss → return to Reader

### 5. Stats
**Purpose:** Reading habits at a glance.

**Layout:**
- Masthead: "Reading" serif 32 + total-words pill
- Today card: words / minutes / articles in three columns
- Weekly bar chart: 7 vertical bars (Mon–Sun), terracotta for today, `paper-deep` for past days, days labeled in mono 11
- Stats grid: streak, average WPM, best WPM, total articles — each as a small card with mono number + sans label

### 6. Settings
**Purpose:** Tune the reader.

**Layout — list of sections, each titled with a SectionLabel:**
- **Reading** — WPM slider, "Pause on punctuation" toggle
- **Focus indicator** — segmented control: Dots / Line / Cross
- **Typography** — segmented control: Serif / Sans / Mono (controls the word font in Reader)
- **About** — version, credits

Use iOS-standard list rows: title on left, control on right, hairline rule between, grouped in cards with 4pt radius and `paper-strong` background.

## Tab Bar (persistent across Library / Add / Read / Stats / Settings — hidden in Focus mode)

- Five tabs, each a stacked icon (22pt) + label (mono 10, uppercase, 0.06em tracking)
- Active tab: terracotta icon + label
- Inactive: `ink-quiet`
- Background: gradient from `paper` (60%) at the bottom up to transparent — gives a soft fade behind scrolling content
- Bottom inset: 28pt for the home indicator

Tabs and SVG icon paths (from `screens.jsx`):
- **Library** — two-page book outline
- **Add** — circle with plus
- **Read** — square with center dot
- **Stats** — four ascending bars
- **Settings** — gear

## Interactions & Behavior

### RSVP Engine (port this logic to the target language)
The engine in `rsvp-core.js` does three things:

1. **Tokenize** — split text on whitespace. Treat `\u00a0` (nbsp) as a regular space.
2. **Focus-letter index** — for each token, pick the character to highlight. Algorithm:
   - Take only "focusable" characters (Unicode letters/numbers): `[\p{L}\p{N}]`
   - If 0 focusable chars: midpoint of the whole token
   - If 1 focusable: index 0 of focusables
   - 2–5 focusables: index 1
   - 6–9: index 2
   - 10–13: index 3
   - 14+: index 4
   - Return the *original* string position of that focusable char
3. **Per-token duration**:
   - Base: `60000 / wpm` ms (clamp wpm to [100, 1200])
   - Length multiplier: if focusable count > 9, add `min((n-9) * 0.07, 0.6)` to the base multiplier
   - Punctuation pause: if `punctuationPause` is on AND token ends in `.!?;:)` (optionally followed by `"')]`), multiply by `1.65`
   - Round to nearest ms

### Reader Transport
- **Play/pause** — toggles a setTimeout chain that advances the word index by 1 each tick using the per-token duration
- **Scrubber** — drag updates word index immediately; resumes if was playing
- **WPM slider** — applies on next tick (don't restart current word)
- **Punctuation pause toggle** — applies on next tick
- **End of article** — auto-pause, show "Done · [N] words in [M] minutes" with a "Mark read" CTA

### Navigation
- Tab bar tap → switch screen (animate? optional, the prototype doesn't)
- Continue-reading card on Library → push Reader, resume at saved word index
- Article row in Library → push Reader, start at word 0 (or saved index)
- Reader expand icon → present Focus mode modally (fullscreen)
- Focus mode dismiss → return to Reader, preserving word index and play state

### State to persist
- Per-article: word index (resume position), times opened, finished flag
- Global: WPM, punctuation-pause flag, focus-indicator style, word typeface
- Stats: words read by day, articles finished, streak

## Sample Content
The prototype includes seed data in `app-data.js`:
- One in-progress article (a fake Atlantic piece on reading and attention) with full text
- 5 library entries with title, source, read time, progress, lede, tag
- Stats: today's totals, 7-day word counts, streak, avg/best WPM, total articles

Replace with real content + Reader-mode HTML extraction (Mercury / Readability / SwiftSoup) when implementing.

## Responsive / Device Notes
- Designed for 390×844pt (iPhone 14 / 15 standard). Should scale up to Pro Max sizes — the word stage gets more vertical room, transport stays the same.
- The HTML prototype is centered in a faux iOS frame for presentation only; ignore the surrounding layout.

## Files in This Bundle

| File | What it is |
|---|---|
| `JustRead iOS App.html` | Main entrypoint — root component, app icon, mounting, Tweaks panel |
| `screens.jsx` | All six screens as React components, plus tab bar and brand mark |
| `rsvp-core.js` | Tokenizer, focus-letter math, per-word duration. **Port this logic.** |
| `app-data.js` | Seed content (current article, library, stats) |
| `ios-frame.jsx` | iOS device bezel (presentation chrome — not part of the app) |
| `tweaks-panel.jsx` | Designer-side tweak controls (not part of the app) |

To preview the design: open `JustRead iOS App.html` in a browser. Tabs in the left sidebar switch screens; the floating Tweaks panel changes WPM, focus indicator style, and word typeface.

## What to Ask the Designer
If anything in the layout, copy, or interaction feels under-specified, ask. The HTML is the source of truth — fall back to it for measurements you can't find in this README.
