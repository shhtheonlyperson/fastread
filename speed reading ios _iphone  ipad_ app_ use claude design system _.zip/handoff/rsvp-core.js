// RSVP reader core — tokenizing, focus-letter splitting, timing.
// Adapted from the user's existing fastread/src/reader-core.js.

const FOCUS_RE = /[\p{L}\p{N}]/u;

window.RSVPCore = {
  tokenize(input) {
    if (typeof input !== 'string') return [];
    return input.replace(/\u00a0/g, ' ').match(/\S+/gu) || [];
  },

  getFocusIndex(token) {
    const chars = Array.from(token || '');
    if (chars.length === 0) return 0;
    const focusable = [];
    chars.forEach((ch, i) => { if (FOCUS_RE.test(ch)) focusable.push(i); });
    if (focusable.length === 0) return Math.floor(chars.length / 2);
    const n = focusable.length;
    let target = 0;
    if (n <= 1) target = 0;
    else if (n <= 5) target = 1;
    else if (n <= 9) target = 2;
    else if (n <= 13) target = 3;
    else target = 4;
    return focusable[Math.min(target, focusable.length - 1)];
  },

  splitForFocus(token) {
    const chars = Array.from(token || '');
    if (chars.length === 0) return { before: '', focus: '', after: '' };
    const i = this.getFocusIndex(token);
    return {
      before: chars.slice(0, i).join(''),
      focus: chars[i] || '',
      after: chars.slice(i + 1).join(''),
    };
  },

  durationForToken(token, wpm, punctuationPause = true) {
    const safeWpm = Math.min(Math.max(Number(wpm) || 450, 100), 1200);
    const base = 60000 / safeWpm;
    const focusable = Array.from(token || '').filter(c => FOCUS_RE.test(c)).length;
    const lengthMult = focusable > 9 ? 1 + Math.min((focusable - 9) * 0.07, 0.6) : 1;
    const pauseMult = punctuationPause && /[.!?;:)]["')\]]*$/u.test(token || '') ? 1.65 : 1;
    return Math.round(base * lengthMult * pauseMult);
  },

  estimateMinutes(wordCount, wpm) {
    const safe = Math.min(Math.max(Number(wpm) || 450, 100), 1200);
    return wordCount / safe;
  },

  clamp(v, mn, mx) { return Math.min(Math.max(v, mn), mx); },
};
