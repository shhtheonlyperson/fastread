// Sample content — news headlines + ledes for the speed reader.

window.RSVPData = {
  // Currently-reading article (a news headline + lede)
  current: {
    title: 'Researchers say a quiet shift in how we read is reshaping attention',
    source: 'The Atlantic',
    author: 'Maya Lindgren',
    date: 'May 2, 2026',
    readTime: '6 min',
    text: `Researchers say a quiet shift in how we read is reshaping attention. For most of the past decade, the conversation around digital reading focused on what was being lost: depth, patience, the long arc of a paragraph. But a new wave of cognitive scientists, working with eye-tracking data and tools that present text one word at a time, argue that something else is happening too. Readers are not simply skimming more. They are renegotiating the basic contract between eye and page, learning to absorb prose in shorter visual jumps and longer mental ones. The implications, these researchers say, are still emerging, but the early evidence suggests that the brain is more elastic about how it takes in language than the long history of the printed book might lead us to believe.`,
  },

  // Library entries
  library: [
    {
      id: 'attention',
      title: 'Researchers say a quiet shift in how we read is reshaping attention',
      source: 'The Atlantic',
      readTime: '6 min',
      progress: 0.34,
      lede: 'For most of the past decade, the conversation around digital reading focused on what was being lost.',
      tag: 'Reading now',
    },
    {
      id: 'memo',
      title: 'The Long-Memo Renaissance',
      source: 'Stratechery',
      readTime: '11 min',
      progress: 0,
      lede: 'Inside the quiet revival of the 3,000-word strategy memo at large technology companies.',
      tag: 'Saved',
    },
    {
      id: 'fed',
      title: 'Fed signals patience as inflation cools to 2.3%',
      source: 'Reuters',
      readTime: '3 min',
      progress: 1,
      lede: 'Policymakers indicated they are in no hurry to cut rates further despite the latest figures.',
      tag: 'Finished',
    },
    {
      id: 'mars',
      title: 'A surprisingly habitable patch of Mars, and what it means',
      source: 'Quanta',
      readTime: '8 min',
      progress: 0.62,
      lede: 'New radar data hints at briny aquifers within a kilometer of the surface.',
      tag: 'Reading now',
    },
    {
      id: 'kitchen',
      title: 'How restaurants quietly redesigned the home kitchen',
      source: 'Eater',
      readTime: '5 min',
      progress: 0,
      lede: 'The professional sheet-pan, the under-counter ice maker, the rise of the second sink.',
      tag: 'Saved',
    },
  ],

  // Stats — last 7 days
  stats: {
    today: { words: 4280, minutes: 11, articles: 2 },
    week: [
      { day: 'Mon', words: 3200 },
      { day: 'Tue', words: 5100 },
      { day: 'Wed', words: 2400 },
      { day: 'Thu', words: 6800 },
      { day: 'Fri', words: 3900 },
      { day: 'Sat', words: 1100 },
      { day: 'Sun', words: 4280 },
    ],
    streak: 12,
    avgWpm: 540,
    bestWpm: 720,
    totalArticles: 47,
  },
};
