# Handoff: JustRead — iOS speed-reader app

## Overview

JustRead is a focused, single-purpose iOS app for reading articles using **RSVP** (Rapid Serial Visual Presentation) — words flash one at a time at a configurable pace, with an Optimal Recognition Point (ORP) letter highlighted in terracotta to anchor the eye. The app pulls articles from URLs or pasted text into a personal library, tracks reading streaks/stats, and offers a fullscreen Focus Mode for distraction-free reading.

The product personality is **warm, paper-like, editorial** — cream-toned backgrounds, Fraunces serif headlines, and a single accent color (terracotta) reserved for the focus letter and primary actions. It deliberately avoids the chrome-heavy look of typical reading apps; the chrome should disappear and the words should breathe.

## About the design files

The files in this bundle are **design references created in HTML/React (via Babel-in-the-browser)**. They are prototypes showing intended look, layout, copy, and behavior — **not production code to copy directly**. Your task is to recreate these designs in the target codebase using its established patterns. For an iOS app this most likely means **SwiftUI** (or UIKit if the existing app is UIKit). If no codebase exists yet, SwiftUI is the recommended target.

The HTML prototype runs in an iOS device frame inside a desktop browser; the device frame, the home-screen-peek decoration, and the side-by-side variant comparison view are presentation chrome — ignore them when implementing the real app. What you are recreating is the content **inside** the device frame: the five screens, the focus-mode overlay, and the RSVP reader behavior.

## Fidelity

**High fidelity.** The mocks include final colors, typography, spacing, copy, and interaction details. Match the visuals as closely as the platform allows. On iOS, native conventions should win where they conflict with HTML approximations — e.g. use the system safe-area insets and Dynamic Island awareness rather than the prototype's hardcoded 47px top inset; use real haptics on the play/pause button; use UIScrollView/ScrollView with native momentum.

## Tech / target environment

- **Recommended target: SwiftUI**, iOS 17+ (uses `.containerRelativeFrame`, `Observable` macro, `ScrollView` paging behaviors).
- iPhone only (the design assumes a single column, ~390pt wide). iPad is a future concern.
- Portrait orientation only for v1.
- Light mode only for v1; the cream paper aesthetic is intentional and a dark mode is a deliberate v2 conversation.

## Screens

There are **5 primary screens** plus a **Focus Mode overlay** plus a (decorative) **app icon**.

Navigation in the prototype is a custom bottom tab bar with 5 tabs: **Library / Add / Reader / Stats / Settings**. In SwiftUI use a `TabView` with custom styling, or a `ZStack` + custom bar if you want to match the prototype's exact look (see "Bottom navigation" below).

### 1. Library (Home)

**Purpose:** the landing screen. User sees today's reading stats, a "Continue reading" card for the article they last opened, and a list of saved articles.

**Layout (top to bottom):**
- **Masthead block** (px 16 horizontal, ~28px top padding below status bar):
  - Row: small JustRead app glyph (28px) on the left + a small uppercased label ("Vol. 47 · Fri") on the right, in `--ink-quiet`. Letterspacing 0.08em, 11px.
  - Large editorial line in **Fraunces 600**, ~28–30px, line-height 1.15, color `--ink`. Two lines: "Today you've read" / "**4,280** words." — the number is in terracotta, the rest in `--ink`.
  - Smaller subline in **Fraunces 400**, 13–14px, color `--ink-quiet`: "11 minutes across 2 articles. Streak: 12 days."
- **Hairline divider** (1px, `--rule`).
- **Continue reading card** (full-bleed inside 16px gutter, `--paper-strong` background, `border-radius: 4px`, hairline border `--rule`, padding 18px):
  - Header row: "Continue reading" small caps label on left + "{read} of {total}" word counter in terracotta on right.
  - Article title in Fraunces 500, 18px, `--ink`, `text-wrap: pretty`. Up to 3 lines.
  - Meta row: source · author · read time in 12px sans-serif `--ink-quiet`.
  - **Resume pill button** bottom-right: terracotta (#c96442) bg, white text, 13px sans-serif 600, `border-radius: 999px`, padding 8/14, with a small ▶ glyph.
  - Thin progress bar inset along bottom edge (height 2px, `--rule` track, terracotta fill at the article's progress %).
- **Hairline divider.**
- **Library list** (16px gutter):
  - Small caps row: "Library" left, "{n} items" right.
  - Stack of rows in a single grouped container (`--paper-strong`, hairline border, 4px radius). Each row:
    - Two columns: title block (flex 1) | tag pill (auto width).
    - Title in Fraunces 500 16px, 1 line truncated with ellipsis, `--ink`.
    - Sub-row: source · read time in 12px sans `--ink-quiet`.
    - Tag pill: tiny uppercased label, `border-radius: 4px`, padding 3/8, 10px font. Color depends on tag:
      - "Reading now" → terracotta text on `rgba(201,100,66,0.10)` bg.
      - "Saved" → `--ink-mid` text on `rgba(31,26,23,0.05)` bg.
      - "Finished" → `--ink-quiet` text, no bg, just a check glyph.
    - Hairline divider between rows (inset 16px from left).
- Bottom padding 140px to clear the floating tab bar.

**Interactions:**
- Tap Continue card → navigate to Reader screen.
- Tap Resume pill → same as tap on card (Reader screen, autoplay).
- Tap library row → Reader screen for that article.
- Long-press on row → action sheet (Mark as read / Delete / Share). _Stub for v1._

### 2. Add (Source)

**Purpose:** paste a URL or text to add a new article to the library.

**Layout:**
- Masthead: "Add a source" Fraunces 600, 26px.
- Sub: "Paste a URL, or drop in raw text." Fraunces 400, 14px, `--ink-quiet`.
- **URL field**: large input, `--paper-strong` bg, 4px radius, hairline border, padding 14/16, monospace font, placeholder "https://…".
- Pill row of recent-source chips below the field (e.g. "The Atlantic", "Stratechery", "Reuters") — small caps, hairline border, tappable to populate.
- Divider, then a smaller **Or paste text** label.
- **Textarea**: 5 lines tall, same styling as URL field but serif font.
- **Add to library** button: full-width, terracotta bg, white text, 16px sans 600, 4px radius, 14px vertical padding. Disabled state: `--paper-deep` bg, `--ink-quiet` text.

**Interactions:**
- Tapping the button shows a brief loading state (~1.2s spinner) then navigates to Reader. _For v1, the URL fetcher should call a real readability backend — see "Open questions" below._
- Recent-source chip tap fills the URL field with that source's homepage.

### 3. Reader

**Purpose:** the RSVP reading experience. One word at a time, focus letter highlighted, controls below.

**Layout (top to bottom):**
- **Top bar**: back arrow (left), article title truncated (center, Fraunces 500 14px), expand-to-focus icon (right). 44pt tall hit areas.
- **Article meta strip**: source · author · date in 12px sans `--ink-quiet`. Centered.
- **Word stage**: ~120pt tall, vertically and horizontally centered. The word is rendered in three spans:
  - `before` letters: `--ink-mid`
  - `focus` letter: terracotta (`#c96442`), same size
  - `after` letters: `--ink-mid`
  - Font size scales with word length: 36pt for ≤6 chars, 32pt for 7–9, 28pt for 10+. Use `--font-serif` (Fraunces) **or** `--font-sans`/`--font-mono` based on the `wordFont` setting.
  - **Focus indicator** sits directly above and below the focus letter. Three styles (user-selectable):
    - **Dot**: a 4pt terracotta dot above and below.
    - **Line**: a short terracotta hairline above and below the focus column.
    - **Crosshair**: a thin vertical terracotta line passing through the focus letter (top to bottom of the stage, 0.5px).
  - The focus letter's horizontal position must remain **fixed** as words change — center the column on the focus letter, not on the word's geometric center. This is the whole point of RSVP and the most easily-broken detail.
- **Progress bar**: 2px tall full-width hairline track, terracotta fill, between the stage and the controls.
- **Control row**: large play/pause button center (terracotta filled circle, 56pt, white glyph), back-15-words and forward-15-words buttons left/right (icon-only, `--ink-mid`).
- **Pace slider row**: "Pace" small-caps label on left + "{wpm} wpm" terracotta on right, then a slider (150–1000, step 25). The slider thumb is terracotta.
- Below the slider, the **next paragraph preview** appears in dim Fraunces 14px, `--ink-quiet` — a small calming peek of what's coming. Optional.

**Interactions:**
- **Play/pause toggles** RSVP. Spacebar / tap-on-stage also toggles.
- While playing, the word advances on a `setTimeout` chain whose delay comes from `RSVPCore.durationForToken(token, wpm, punctPause)` — variable timing that adds a 1.65× multiplier for tokens ending in punctuation, and a length multiplier for long words.
- ←/→ skip 15 words.
- Drag the slider → live update wpm and persist (and continue at the new pace if playing).
- Tap expand → enter Focus Mode.
- Reaching the end of tokens stops playback and shows a "Done" pill.
- Persist current `index` per-article to local storage.

### 4. Stats

**Purpose:** progress and pace history.

**Layout:**
- Masthead "Stats" Fraunces 600 26px.
- **Stat-card grid**, 2 cols, 12px gap:
  - Streak (large terracotta number + "days" caption + tiny calendar dot row).
  - Avg wpm.
  - Best wpm.
  - Total articles.
  - Each card: `--paper-strong` bg, 4px radius, hairline border, 16px padding. Big number in Fraunces 600 32px.
- **This week bar chart**: 7 vertical bars (Mon–Sun), each labeled with a 11px small-caps day label below. Bar fill is `--ink-mid`; today's bar is terracotta. Y axis is omitted; max bar = max value in week. Hover/tap bar shows a tooltip with exact word count. Chart height ~140pt.
- **Recently finished list**: same row style as Library but only items with `progress: 1`.

### 5. Settings

**Purpose:** reading preferences.

**Layout:**
- Sectioned list (grouped iOS style), each section in a `--paper-strong` rounded container with hairline borders between rows.
- **Reading section**:
  - Words per minute: slider 150–1000 step 25, current value on right.
  - Pause on punctuation: toggle.
- **Focus indicator section**: segmented control with Dots / Line / Cross.
- **Typography section**: segmented control with Serif / Sans / Mono for the word stage font.
- **Account section** (stub): Sign in with Apple, Restore purchases.
- **About section** (stub): Version, Privacy, Open-source licenses.

### Focus Mode (overlay)

A fullscreen modal that takes over the whole device frame. Same word stage as the Reader, but:
- Black or `--ink` background, paper-cream text.
- Terracotta focus letter is even more prominent against the dark background.
- Minimal chrome: small × top-right to dismiss; pace slider only appears on tap-anywhere.
- Tap stage to play/pause.
- Holds device awake (use `UIApplication.shared.isIdleTimerDisabled = true` while open).

## Bottom navigation

Floating glass-y tab bar, fixed to bottom, 16px from screen edges, ~64pt tall, `border-radius: 22pt`, **backdrop blur** (`UIVisualEffectView` with `.systemUltraThinMaterial`), thin terracotta-tinted border. 5 tabs:

| Tab | Glyph | Label |
|---|---|---|
| Library | book stack | "Library" |
| Add | plus circle | "Add" |
| Reader | bullet dot | "Read" |
| Stats | bar chart | "Stats" |
| Settings | sliders | "More" |

Active tab: terracotta glyph + label. Inactive: `--ink-quiet`. Labels are 10px small-caps. Hit area 44×44pt minimum.

## Design tokens

### Colors

```
paper            #f5efe2   primary background
paper-strong     #faf6ec   card / inset surfaces
paper-deep       #ece4d2   pressed / disabled surfaces
ink              #1f1a17   primary text
ink-mid          #4a3f37   secondary text
ink-quiet        #8a7a6a   tertiary text / labels
rule             rgba(31,26,23,0.08)   hairlines
rule-strong      rgba(31,26,23,0.18)   stronger hairlines / slider tracks
terracotta       #c96442   accent: focus letter, CTA, progress, today's bar
```

The body background behind the device frame uses two radial gradients on `#e8e0cf` — that's the prototype's desktop staging only; on real iOS use solid `paper`.

### Typography

- **Serif:** Fraunces (Variable, opsz 9–144). Weights used: 400, 500, 600, 700. Headlines, the word stage default, article titles.
- **Sans:** Inter. Weights 400/500/600/700. UI labels, buttons, meta.
- **Mono:** JetBrains Mono. Weights 400/500. The URL input, token-count debug labels.

iOS substitutions if Fraunces isn't bundled: **New York** is a reasonable system fallback (it's the closest Apple ships to Fraunces' editorial feel). For sans, **SF Pro** is fine. Bundle Fraunces as a TTF for fidelity.

Type scale (px in the HTML; treat as pt on iOS):

| Use | Family | Size | Weight | Line height |
|---|---|---|---|---|
| Hero number | Fraunces | 30 | 600 | 1.15 |
| Screen title | Fraunces | 26 | 600 | 1.2 |
| Article title (card) | Fraunces | 18 | 500 | 1.3 |
| Article title (row) | Fraunces | 16 | 500 | 1.35 |
| Body / "Today" subline | Fraunces | 14 | 400 | 1.55 |
| Meta / source | Inter | 12 | 400 | 1.4 |
| Small caps label | Inter | 11 | 600 | 1, letter-spacing 0.08em, uppercase |
| Tag pill | Inter | 10 | 600 | 1, letter-spacing 0.06em, uppercase |
| Word stage (short word) | Fraunces | 36 | 500 | 1 |
| Word stage (long word) | Fraunces | 28 | 500 | 1 |

### Spacing & radii

- Screen gutter: **16pt**.
- Card padding: **16–18pt**.
- Vertical rhythm between sections: **22–28pt**.
- Card radius: **4pt** (intentionally tight — this design avoids the soft 12pt+ radii of most modern iOS apps; it's part of the editorial feel).
- Pill / button radius: **999pt** (full).
- Tab bar radius: **22pt**.
- Hairline borders: **0.5pt** (or 1px in HTML); use `1.0 / UIScreen.main.scale` on iOS.

### Motion

- Screen transitions: standard iOS push (no custom required).
- Tab change: cross-fade 180ms, no slide.
- Play/pause button: scale to 0.94 on press, 120ms ease-out.
- Word stage swap: no transition — instant swap is the RSVP convention. Adding a fade kills the effect.
- Focus mode entry: scale-from-87% + fade, 240ms ease-out.

## State

```swift
@Observable
class JustReadStore {
    var library: [Article]
    var currentArticleID: Article.ID?
    var stats: Stats        // streak, avgWpm, bestWpm, totalArticles, week: [DayStat]
    var settings: Settings  // wpm, punctPause, focusStyle, wordFont, locale
    var readingProgress: [Article.ID: Int]  // token index per article
}

struct Article {
    let id: UUID
    var title: String
    var source: String
    var author: String?
    var date: Date
    var readTimeMinutes: Int
    var text: String
    var tag: Tag    // .readingNow / .saved / .finished
}
```

Persist `settings`, `readingProgress`, and `library` to disk (SwiftData or a JSON blob in the app's documents directory).

## RSVP core logic

The prototype's `rsvp-core.js` is small and reasonably tested — port it directly to Swift. Key functions:

- **`tokenize(text) -> [String]`**: splits Latin text on whitespace, splits CJK text into 2-character chunks (with punctuation attached). The CJK path matters because the app supports Traditional Chinese in v1.
- **`getFocusIndex(token) -> Int`**: returns the index of the ORP letter using length-based lookup table:
  - 1 letter → 0
  - 2–5 → index 1
  - 6–9 → index 2
  - 10–13 → index 3
  - 14+ → index 4
- **`splitForFocus(token)`**: returns `(before, focus, after)` for rendering.
- **`durationForToken(token, wpm, punctPause)`**: returns ms to display this token.
  - Base = `60_000 / wpm`.
  - CJK chunks: 1.5× multiplier (denser glyphs).
  - Long Latin words (>9 focusable chars): up to 1.6× multiplier.
  - Tokens ending in `.,!?;:` (or CJK equivalents): 1.65× multiplier when `punctPause` is on.

## Localization

**v1 ships English + Traditional Chinese (繁體中文).** Strings live in `app-data.js` under `locales[en|zh-Hant]`. On iOS use standard `Localizable.strings` files; the prototype's structure (a `ui` object of strings + lambda formatters for plural/pattern strings) maps to:
- Static strings → `Localizable.strings`.
- Pattern strings (e.g. "{minutes} minutes across {articles} articles. Streak: {streak} days.") → `String(localized:)` with interpolation, or `String(format:)`.

Sample articles and library titles are also localized — preserve that pattern. The Chinese sample text is included so you can wire it in directly.

The HomeScreen masthead label and the Continue card word counter both have `whiteSpace: nowrap` because Chinese rendering wraps on character boundaries by default — replicate this with `.fixedSize(horizontal: true, vertical: false)` in SwiftUI.

## Tweaks

The prototype has an in-design Tweaks panel exposing `wpm`, `punctPause`, `focusStyle`, `wordFont`, `screen`, `locale`. **These are design-time controls only** — in the real app, `screen` is just navigation, and the rest live in the Settings screen.

## Files in this bundle

| File | What it is |
|---|---|
| `JustRead iOS App.html` | Entry HTML — set up React/Babel, define `App`, route between screens, host the Tweaks panel. |
| `screens.jsx` | All five screens + Focus Mode + shared `<SectionLabel>`, `<JustReadIcon>`, library row, etc. The bulk of the design lives here. |
| `rsvp-core.js` | The tokenizer + focus-index + duration logic. Port to Swift verbatim. |
| `app-data.js` | Sample article content, library, and localized UI strings for `en` and `zh-Hant`. |
| `ios-frame.jsx` | The desktop-only iPhone bezel + status bar. **Do not port this** — use real iOS chrome. |
| `tweaks-panel.jsx` | The in-design tweak controls. **Do not port this** — Settings screen replaces it. |

## Open questions for the developer

1. **URL → article extraction.** The prototype hand-types article text. The real app needs a readability extractor. Options: ship with [Readability.js](https://github.com/mozilla/readability) inside a hidden `WKWebView`; or use a server-side extractor (Mercury/Readability API). Recommend the WKWebView approach — no backend, works offline-after-fetch.
2. **Sync.** v1 single-device with local persistence is fine. CloudKit sync is a v2 question.
3. **Article images.** Prototype has none. Should the Reader pre-show a hero image before the RSVP starts? _Open question — flag for product._
4. **Audio.** RSVP + TTS is a natural pairing. Out of scope for v1; flagged.
5. **Onboarding.** Not designed. First-launch flow needs a calibration pass to set initial wpm — prototype assumes 540 by default.

## Implementation order suggestion

1. Set up project structure + design tokens (Color/Font extensions).
2. Build Library screen with hardcoded `app-data.js` data.
3. Port `rsvp-core` to Swift, write tests for `tokenize`, `getFocusIndex`, `durationForToken`.
4. Build Reader screen — get a single hardcoded article RSVP-ing correctly. **Verify focus letter stays in fixed horizontal position across word changes.**
5. Add Settings, wire its controls to Reader.
6. Add Stats with hardcoded data.
7. Add Focus Mode overlay.
8. Add URL extraction via WKWebView + Readability.js.
9. Persist library + progress + settings.
10. Localization pass (en + zh-Hant).
