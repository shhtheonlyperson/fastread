// RSVP reader core — tokenizing, focus-letter splitting, timing.
// Adapted from the user's existing fastread/src/reader-core.js.

const FOCUS_RE = /[\p{L}\p{N}]/u;

// CJK detection — Han, Hiragana, Katakana, Hangul, plus CJK punctuation.
const CJK_CHAR = /[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\uac00-\ud7af]/;
const CJK_PUNCT = /[\u3000-\u303f\uff00-\uffef]/;

function hasCJK(s) { return CJK_CHAR.test(s || ''); }

// Tokenize a CJK string into 2-char chunks, breaking on whitespace + CJK
// punctuation. Punctuation gets attached to the prior chunk so durationForToken
// can detect it for the pause multiplier.
function tokenizeCJK(input) {
  const tokens = [];
  let buf = '';
  const flush = () => { if (buf) { tokens.push(buf); buf = ''; } };
  const chars = Array.from(input);
  for (let i = 0; i < chars.length; i++) {
    const ch = chars[i];
    if (/\s/.test(ch)) { flush(); continue; }
    if (CJK_PUNCT.test(ch) || /[.,!?;:]/.test(ch)) {
      // Attach punctuation to the current buffer if any, else previous token.
      if (buf) { buf += ch; flush(); }
      else if (tokens.length) { tokens[tokens.length - 1] += ch; }
      continue;
    }
    if (CJK_CHAR.test(ch)) {
      buf += ch;
      // Chunk into pairs of 2 CJK chars
      if (Array.from(buf).filter(c => CJK_CHAR.test(c)).length >= 2) flush();
    } else {
      // Latin run inside CJK text → flush CJK buffer, accumulate Latin word
      flush();
      let word = ch;
      while (i + 1 < chars.length && !/\s/.test(chars[i + 1]) && !CJK_CHAR.test(chars[i + 1]) && !CJK_PUNCT.test(chars[i + 1])) {
        i++; word += chars[i];
      }
      tokens.push(word);
    }
  }
  flush();
  return tokens;
}

window.RSVPCore = {
  tokenize(input) {
    if (typeof input !== 'string') return [];
    if (hasCJK(input)) return tokenizeCJK(input);
    return input.replace(/\u00a0/g, ' ').match(/\S+/gu) || [];
  },

  getFocusIndex(token) {
    const chars = Array.from(token || '');
    if (chars.length === 0) return 0;
    const focusable = [];
    chars.forEach((ch, i) => { if (FOCUS_RE.test(ch)) focusable.push(i); });
    if (focusable.length === 0) return Math.floor(chars.length / 2);
    const n = focusable.length;
    let target = 0;
    if (n <= 1) target = 0;
    else if (n <= 5) target = 1;
    else if (n <= 9) target = 2;
    else if (n <= 13) target = 3;
    else target = 4;
    return focusable[Math.min(target, focusable.length - 1)];
  },

  splitForFocus(token) {
    const chars = Array.from(token || '');
    if (chars.length === 0) return { before: '', focus: '', after: '' };
    const i = this.getFocusIndex(token);
    return {
      before: chars.slice(0, i).join(''),
      focus: chars[i] || '',
      after: chars.slice(i + 1).join(''),
    };
  },

  durationForToken(token, wpm, punctuationPause = true) {
    const safeWpm = Math.min(Math.max(Number(wpm) || 450, 100), 1200);
    const base = 60000 / safeWpm;
    const isCJK = hasCJK(token);
    const focusable = Array.from(token || '').filter(c => FOCUS_RE.test(c) || CJK_CHAR.test(c)).length;
    // CJK chunks of 2 chars are denser → give them ~1.5x the base time.
    const cjkMult = isCJK ? 1.5 : 1;
    const lengthMult = focusable > 9 ? 1 + Math.min((focusable - 9) * 0.07, 0.6) : 1;
    const punctRe = isCJK ? /[\u3000-\u303f\uff00-\uffef.,!?;:]$/u : /[.!?;:)]["')\]]*$/u;
    const pauseMult = punctuationPause && punctRe.test(token || '') ? 1.65 : 1;
    return Math.round(base * cjkMult * lengthMult * pauseMult);
  },

  estimateMinutes(wordCount, wpm) {
    const safe = Math.min(Math.max(Number(wpm) || 450, 100), 1200);
    return wordCount / safe;
  },

  clamp(v, mn, mx) { return Math.min(Math.max(v, mn), mx); },
};
