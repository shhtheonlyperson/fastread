// Sample content — news headlines + ledes for the speed reader.

window.RSVPData = {
  // Locale data — strings + sample content per language. Default is 'en';
  // Tweaks panel can switch this to 'zh-Hant' for Traditional Chinese.
  locales: {
    en: {
      label: 'English',
      // UI strings
      ui: {
        date: 'May 2',
        volume: 'Vol. 47 · Fri',
        todayPrefix: "Today you've read",
        todaySuffix: 'words.',
        todayMeta: ({minutes, articles, streak}) => `${minutes} minutes across ${articles} articles. Streak: ${streak} days.`,
        continueReading: 'Continue reading',
        ofWords: ({read, total}) => `${read} of ${total}`,
        resume: 'Resume',
        library: 'Library',
        items: (n) => `${n} items`,
        readingNow: 'Reading now',
        saved: 'Saved',
        finished: 'Finished',
      },
      current: {
        title: 'Researchers say a quiet shift in how we read is reshaping attention',
        source: 'The Atlantic',
        author: 'Maya Lindgren',
        date: 'May 2, 2026',
        readTime: '6 min',
        text: `Researchers say a quiet shift in how we read is reshaping attention. For most of the past decade, the conversation around digital reading focused on what was being lost: depth, patience, the long arc of a paragraph. But a new wave of cognitive scientists, working with eye-tracking data and tools that present text one word at a time, argue that something else is happening too. Readers are not simply skimming more. They are renegotiating the basic contract between eye and page, learning to absorb prose in shorter visual jumps and longer mental ones. The implications, these researchers say, are still emerging, but the early evidence suggests that the brain is more elastic about how it takes in language than the long history of the printed book might lead us to believe.`,
      },
      library: [
        { id: 'attention', title: 'Researchers say a quiet shift in how we read is reshaping attention', source: 'The Atlantic', readTime: '6 min', progress: 0.34, tag: 'Reading now' },
        { id: 'memo', title: 'The Long-Memo Renaissance', source: 'Stratechery', readTime: '11 min', progress: 0, tag: 'Saved' },
        { id: 'fed', title: 'Fed signals patience as inflation cools to 2.3%', source: 'Reuters', readTime: '3 min', progress: 1, tag: 'Finished' },
        { id: 'mars', title: 'A surprisingly habitable patch of Mars, and what it means', source: 'Quanta', readTime: '8 min', progress: 0.62, tag: 'Reading now' },
        { id: 'kitchen', title: 'How restaurants quietly redesigned the home kitchen', source: 'Eater', readTime: '5 min', progress: 0, tag: 'Saved' },
      ],
    },
    'zh-Hant': {
      label: '繁體中文',
      ui: {
        date: '5月2日',
        volume: '第 47 期 · 週五',
        todayPrefix: '今天你已閱讀',
        todaySuffix: '個字',
        todayMeta: ({minutes, articles, streak}) => `${minutes} 分鐘,共 ${articles} 篇文章。連續 ${streak} 天。`,
        continueReading: '繼續閱讀',
        ofWords: ({read, total}) => `${read} / ${total}`,
        resume: '繼續',
        library: '書架',
        items: (n) => `${n} 項`,
        readingNow: '閱讀中',
        saved: '已儲存',
        finished: '已讀完',
      },
      current: {
        title: '研究人員指出,我們閱讀方式的悄然轉變正在重塑注意力',
        source: '大西洋月刊',
        author: '林格倫',
        date: '2026 年 5 月 2 日',
        readTime: '6 分鐘',
        text: `研究人員指出,我們閱讀方式的悄然轉變正在重塑注意力。過去十年來,關於數位閱讀的討論大多聚焦於我們失去了什麼:深度、耐心,以及一個段落綿長的弧線。然而,一批新的認知科學家,藉由眼動追蹤資料以及一次只呈現一個詞的工具,主張另一件事也正在發生。讀者並不只是略讀得更多。他們正在重新協商眼睛與頁面之間最基本的契約,學會以更短的視覺跳躍與更長的心智延展來吸收散文。這些研究人員表示,影響仍在浮現,但初步證據顯示,大腦對語言吸收方式的彈性,比印刷書漫長的歷史所暗示的還要大。`,
      },
      library: [
        { id: 'attention', title: '研究人員指出,我們閱讀方式的悄然轉變正在重塑注意力', source: '大西洋月刊', readTime: '6 分鐘', progress: 0.34, tag: '閱讀中' },
        { id: 'memo', title: '長備忘錄的復興', source: 'Stratechery', readTime: '11 分鐘', progress: 0, tag: '已儲存' },
        { id: 'fed', title: '通膨降至 2.3%,聯準會表示將保持耐心', source: '路透社', readTime: '3 分鐘', progress: 1, tag: '已讀完' },
        { id: 'mars', title: '火星上一處意外宜居的地帶,以及它的意義', source: 'Quanta', readTime: '8 分鐘', progress: 0.62, tag: '閱讀中' },
        { id: 'kitchen', title: '餐廳如何悄悄地重新設計了家庭廚房', source: 'Eater', readTime: '5 分鐘', progress: 0, tag: '已儲存' },
      ],
    },
  },

  // Active locale getter — returns merged data for the current locale
  setLocale(loc) { this.activeLocale = loc; this._refresh(); },
  _refresh() {
    const L = this.locales[this.activeLocale] || this.locales.en;
    this.ui = L.ui;
    this.current = L.current;
    this.library = L.library;
  },

  activeLocale: 'en',

  // Stats — last 7 days
  stats: {
    today: { words: 4280, minutes: 11, articles: 2 },
    week: [
      { day: 'Mon', words: 3200 },
      { day: 'Tue', words: 5100 },
      { day: 'Wed', words: 2400 },
      { day: 'Thu', words: 6800 },
      { day: 'Fri', words: 3900 },
      { day: 'Sat', words: 1100 },
      { day: 'Sun', words: 4280 },
    ],
    streak: 12,
    avgWpm: 540,
    bestWpm: 720,
    totalArticles: 47,
  },
};

// Initialize active locale data
window.RSVPData._refresh();