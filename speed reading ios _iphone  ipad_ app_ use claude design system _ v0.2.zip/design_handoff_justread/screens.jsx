// JustRead v0.1 snapshot — original screens. Speed reader screens. All 6 screens as React components.
// Uses RSVPCore + RSVPData on window. Uses Claude design tokens via CSS vars.

const { useState, useEffect, useRef, useMemo, useCallback } = React;

// ─── Brand mark / app icon ───────────────────────────────────
function JustReadIcon({ size = 56, radius }) {
  const r = radius ?? size * 0.225;
  return (
    <div style={{
      width: size, height: size, borderRadius: r,
      background: 'linear-gradient(160deg, #f3ece1 0%, #e9dcc5 70%, #d9c8aa 100%)',
      position: 'relative', overflow: 'hidden',
      boxShadow: '0 1px 0 rgba(255,255,255,0.6) inset, 0 0 0 0.5px rgba(0,0,0,0.08)',
      flexShrink: 0,
    }}>
      {/* paper grain */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'repeating-linear-gradient(0deg, transparent 0 7px, rgba(0,0,0,0.025) 7px 8px)',
        mixBlendMode: 'multiply', opacity: 0.7,
      }} />
      {/* T mark + terracotta dot (the focus letter) */}
      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        paddingLeft: size * 0.04,
        fontFamily: '"Fraunces", "Tiempos Headline", Georgia, serif',
        fontWeight: 600, fontSize: size * 0.5,
        letterSpacing: -size * 0.01, lineHeight: 1.15,
        paddingTop: size * 0.04,
      }}>
        <span style={{ position: 'relative', display: 'inline-flex', alignItems: 'baseline' }}>
          {/* J — sans-serif, subtle companion, sized to match R's cap height */}
          <span style={{
            color: 'rgba(43,38,34,0.55)',
            marginRight: -size * 0.1,
            fontFamily: '"Inter", -apple-system, BlinkMacSystemFont, "Helvetica Neue", sans-serif',
            fontWeight: 500,
            fontSize: '0.92em',
          }}>J</span>
          {/* R — the focus letter, terracotta */}
          <span style={{
            color: '#c96442',
            fontWeight: 700,
          }}>R</span>
          {/* Focus dot — the RSVP anchor */}
          <span style={{
            position: 'absolute', top: size * 0.06, right: -size * 0.14,
            width: size * 0.11, height: size * 0.11, borderRadius: '50%',
            background: '#c96442',
          }} />
        </span>
      </div>
    </div>
  );
}

// ─── Section header (uppercase tracked label) ────────────────
function SectionLabel({ children, style }) {
  return (
    <div style={{
      fontFamily: 'var(--font-mono)',
      fontSize: 11, fontWeight: 500, letterSpacing: '0.14em',
      textTransform: 'uppercase', color: 'var(--ink-quiet)',
      ...style,
    }}>{children}</div>
  );
}

// ─── Tab bar ─────────────────────────────────────────────────
function JustReadTabBar({ active, onChange }) {
  const tabs = [
    { id: 'home', label: 'Library', icon: (c) => (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
        <path d="M4 5.5C4 4.67 4.67 4 5.5 4H10v14H5.5A1.5 1.5 0 014 16.5v-11z" stroke={c} strokeWidth="1.4"/>
        <path d="M12 4h4.5C17.33 4 18 4.67 18 5.5v11a1.5 1.5 0 01-1.5 1.5H12V4z" stroke={c} strokeWidth="1.4"/>
      </svg>
    )},
    { id: 'source', label: 'Add', icon: (c) => (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
        <circle cx="11" cy="11" r="8" stroke={c} strokeWidth="1.4"/>
        <path d="M11 7v8M7 11h8" stroke={c} strokeWidth="1.4" strokeLinecap="round"/>
      </svg>
    )},
    { id: 'reader', label: 'Read', icon: (c) => (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
        <path d="M5 5h12v12H5z" stroke={c} strokeWidth="1.4"/>
        <circle cx="11" cy="11" r="2" fill={c}/>
      </svg>
    )},
    { id: 'stats', label: 'Stats', icon: (c) => (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
        <path d="M4 17V9M9 17V5M14 17v-7M19 17V8" stroke={c} strokeWidth="1.4" strokeLinecap="round"/>
      </svg>
    )},
    { id: 'settings', label: 'Settings', icon: (c) => (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
        <circle cx="11" cy="11" r="3" stroke={c} strokeWidth="1.4"/>
        <path d="M11 2v3M11 17v3M2 11h3M17 11h3M4.5 4.5l2.1 2.1M15.4 15.4l2.1 2.1M4.5 17.5l2.1-2.1M15.4 6.6l2.1-2.1" stroke={c} strokeWidth="1.4" strokeLinecap="round"/>
      </svg>
    )},
  ];

  return (
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      paddingBottom: 28, paddingTop: 10, paddingInline: 12,
      background: 'linear-gradient(to top, var(--paper) 60%, rgba(245,238,225,0))',
      display: 'flex', justifyContent: 'space-around', alignItems: 'flex-end',
      zIndex: 30,
    }}>
      {tabs.map(t => {
        const on = active === t.id;
        const c = on ? 'var(--terracotta)' : 'var(--ink-quiet)';
        return (
          <button key={t.id} onClick={() => onChange(t.id)} style={{
            background: 'transparent', border: 0, cursor: 'pointer',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
            padding: '6px 8px', flex: 1, minWidth: 0,
          }}>
            {t.icon(c)}
            <div style={{
              fontFamily: 'var(--font-mono)', fontSize: 10, letterSpacing: '0.06em',
              color: c, fontWeight: 500, textTransform: 'uppercase',
            }}>{t.label}</div>
          </button>
        );
      })}
    </div>
  );
}

// ─── Home / Library ──────────────────────────────────────────
function HomeScreen({ goto, onResume }) {
  const data = window.RSVPData;
  return (
    <div style={{ paddingBottom: 140, color: 'var(--ink)' }}>
      {/* Editorial masthead */}
      <div style={{ padding: '60px 24px 18px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }}>
          <JustReadIcon size={28} />
          <SectionLabel style={{ whiteSpace: 'nowrap' }}>{data.ui.volume}</SectionLabel>
        </div>
        <div style={{
          fontFamily: 'var(--font-serif)',
          fontSize: 38, lineHeight: 1.02, fontWeight: 500,
          letterSpacing: -1, color: 'var(--ink)',
          textWrap: 'pretty',
        }}>
          {data.ui.todayPrefix}<br/>
          <span style={{ color: 'var(--terracotta)' }}>{data.stats.today.words.toLocaleString()}</span> {data.ui.todaySuffix}
        </div>
        <div style={{
          marginTop: 10, fontFamily: 'var(--font-sans)', fontSize: 14,
          color: 'var(--ink-quiet)', lineHeight: 1.5,
        }}>
          {data.ui.todayMeta({ minutes: data.stats.today.minutes, articles: data.stats.today.articles, streak: data.stats.streak })}
        </div>
      </div>

      {/* Continue reading hero */}
      <div style={{ padding: '0 16px' }}>
        <div onClick={onResume} style={{
          background: 'var(--paper-strong)', borderRadius: 4,
          border: '0.5px solid var(--rule)',
          padding: 18, cursor: 'pointer',
          display: 'flex', flexDirection: 'column', gap: 12,
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <SectionLabel>{data.ui.continueReading}</SectionLabel>
            <SectionLabel style={{ color: 'var(--terracotta)', whiteSpace: 'nowrap' }}>{(() => { const t = window.RSVPCore.tokenize(data.current.text).length; return data.ui.ofWords({ read: Math.round(t * 0.34), total: t }); })()}</SectionLabel>
          </div>
          <div style={{
            fontFamily: 'var(--font-serif)', fontSize: 22, lineHeight: 1.18,
            fontWeight: 500, letterSpacing: -0.3, color: 'var(--ink)',
            textWrap: 'pretty',
          }}>
            {data.current.title}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ flex: 1, height: 2, background: 'var(--rule)', borderRadius: 2, overflow: 'hidden' }}>
              <div style={{ width: '34%', height: '100%', background: 'var(--terracotta)' }}/>
            </div>
            <div style={{
              fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--ink-quiet)',
              letterSpacing: '0.06em',
            }}>34%</div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: 'var(--ink-mid)' }}>
              {data.current.source} · {data.current.readTime}
            </div>
            <div style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              padding: '7px 12px', borderRadius: 999, background: 'var(--terracotta)',
              color: '#fff', fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 600,
              letterSpacing: -0.1,
            }}>
              <svg width="9" height="11" viewBox="0 0 9 11" fill="#fff"><path d="M0 0v11l9-5.5z"/></svg>
              {data.ui.resume}
            </div>
          </div>
        </div>
      </div>

      {/* Library list — title only */}
      <div style={{ padding: '28px 16px 0' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', padding: '0 8px 12px' }}>
          <SectionLabel>{data.ui.library}</SectionLabel>
          <SectionLabel style={{ opacity: 0.5 }}>{data.ui.items(data.library.length)}</SectionLabel>
        </div>
        <div style={{ background: 'var(--paper-strong)', borderRadius: 4, border: '0.5px solid var(--rule)' }}>
          {data.library.map((item, idx) => (
            <div key={item.id} style={{
              padding: '14px 16px',
              borderTop: idx === 0 ? 0 : '0.5px solid var(--rule)',
              display: 'flex', flexDirection: 'column', gap: 6,
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{
                  width: 8, height: 8, borderRadius: '50%',
                  background: item.progress === 1 ? 'var(--ink-quiet)'
                    : item.progress > 0 ? 'var(--terracotta)' : 'transparent',
                  border: item.progress === 0 ? '1px solid var(--ink-quiet)' : 'none',
                  flexShrink: 0,
                }}/>
                <SectionLabel style={{ flex: 1 }}>{item.tag}</SectionLabel>
                <div style={{
                  fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--ink-quiet)',
                  letterSpacing: '0.06em',
                }}>{item.readTime}</div>
              </div>
              <div style={{
                fontFamily: 'var(--font-serif)', fontSize: 16, lineHeight: 1.25,
                fontWeight: 500, letterSpacing: -0.2, color: 'var(--ink)',
                textWrap: 'pretty',
              }}>{item.title}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Source / Add screen ─────────────────────────────────────
// Detect whether text looks like a URL.
// Permissive: accepts "https://...", "http://...", or bare hosts like "stratechery.com/article".
const URL_RE = /^(https?:\/\/\S+|(?:[a-z0-9-]+\.)+[a-z]{2,}(?:\/\S*)?)$/i;
function looksLikeUrl(s) {
  const t = (s || '').trim();
  if (!t || /\s/.test(t)) return false;          // multiple words → text
  return URL_RE.test(t);
}

function SourceScreen({ onLoaded }) {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState('');

  const trimmed = input.trim();
  const isUrl = looksLikeUrl(trimmed);
  const hasInput = trimmed.length > 0;
  const wordCount = hasInput && !isUrl ? trimmed.split(/\s+/).length : 0;

  // Action label changes based on what's in the box
  let actionLabel = 'Paste or type to begin';
  if (loading) actionLabel = 'Fetching article…';
  else if (isUrl) actionLabel = 'Fetch & open in reader';
  else if (hasInput) actionLabel = `Open ${wordCount.toLocaleString()} words in reader`;

  const handleAction = () => {
    if (!hasInput || loading) return;
    if (isUrl) {
      setLoading(true);
      setStatus('');
      setTimeout(() => {
        setLoading(false);
        setStatus('Article fetched. Opening reader…');
        setTimeout(() => onLoaded(), 400);
      }, 900);
    } else {
      onLoaded();
    }
  };

  return (
    <div style={{ paddingBottom: 140, color: 'var(--ink)' }}>
      <div style={{ padding: '60px 24px 18px' }}>
        <SectionLabel>New reading</SectionLabel>
        <div style={{
          marginTop: 8,
          fontFamily: 'var(--font-serif)', fontSize: 36, lineHeight: 1.05,
          fontWeight: 500, letterSpacing: -0.9, color: 'var(--ink)',
        }}>Add something<br/>to read.</div>
        <div style={{
          marginTop: 14, fontFamily: 'var(--font-sans)', fontSize: 14,
          color: 'var(--ink-mid)', lineHeight: 1.5, maxWidth: 320,
        }}>Paste a link or any text. We'll figure out which it is.</div>
      </div>

      <div style={{ padding: '0 24px' }}>
        {/* Single smart input — grows as you type */}
        <div style={{ position: 'relative' }}>
          <textarea
            value={input}
            onChange={e => { setInput(e.target.value); setStatus(''); }}
            placeholder="https://example.com/article  —  or paste an article, memo, or transcript…"
            rows={isUrl ? 1 : 6}
            style={{
              width: '100%',
              minHeight: isUrl ? 52 : 180,
              resize: 'none',
              padding: '14px 16px',
              paddingRight: 78, // room for the mode badge
              border: '0.5px solid var(--rule-strong)',
              background: 'var(--paper-strong)',
              borderRadius: 4,
              fontFamily: isUrl ? 'var(--font-mono)' : 'var(--font-serif)',
              fontSize: isUrl ? 13 : 15,
              lineHeight: isUrl ? 1.4 : 1.5,
              color: 'var(--ink)',
              outline: 'none',
              boxSizing: 'border-box',
              transition: 'min-height 0.2s, font-family 0.15s',
            }}
          />
          {/* Mode badge — top-right of input */}
          {hasInput && (
            <div style={{
              position: 'absolute', top: 12, right: 12,
              padding: '3px 8px', borderRadius: 999,
              background: isUrl ? 'var(--terracotta)' : 'var(--ink)',
              color: '#fff',
              fontFamily: 'var(--font-mono)', fontSize: 10,
              fontWeight: 500, letterSpacing: '0.12em', textTransform: 'uppercase',
            }}>{isUrl ? 'Link' : 'Text'}</div>
          )}
        </div>

        {/* Status line — only after fetch */}
        {status && (
          <div style={{
            marginTop: 10, fontFamily: 'var(--font-mono)', fontSize: 11,
            color: 'var(--terracotta)',
            letterSpacing: '0.06em', textTransform: 'uppercase',
          }}>{status}</div>
        )}

        {/* One button — label morphs based on input */}
        <button
          disabled={!hasInput || loading}
          onClick={handleAction}
          style={{
            marginTop: 14, width: '100%', height: 52, borderRadius: 4,
            background: hasInput ? 'var(--ink)' : 'var(--rule-strong)',
            color: '#fff', border: 0,
            fontFamily: 'var(--font-sans)', fontSize: 15, fontWeight: 600,
            letterSpacing: -0.1, cursor: hasInput && !loading ? 'pointer' : 'default',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            transition: 'background 0.15s',
          }}>
          {loading && (
            <div style={{
              width: 14, height: 14, borderRadius: '50%',
              border: '1.5px solid rgba(255,255,255,0.3)',
              borderTopColor: '#fff',
              animation: 'jr-spin 0.7s linear infinite',
            }}/>
          )}
          {actionLabel}
          {!loading && hasInput && <span style={{ opacity: 0.6 }}>→</span>}
        </button>
        <style>{`@keyframes jr-spin { to { transform: rotate(360deg); } }`}</style>

        <div style={{ marginTop: 28 }}>
          <SectionLabel style={{ marginBottom: 12 }}>Recent sources</SectionLabel>
          {[
            { label: 'stratechery.com', date: '2h ago' },
            { label: 'theatlantic.com', date: 'yesterday' },
            { label: 'reuters.com', date: '3 days ago' },
          ].map((r, i) => (
            <div key={i} style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '12px 0',
              borderTop: i === 0 ? '0.5px solid var(--rule)' : '0.5px solid var(--rule)',
            }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--ink)' }}>{r.label}</div>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: 'var(--ink-quiet)' }}>{r.date}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── RSVP Stage (the one-word view) ──────────────────────────
function RSVPStage({ token, big = false, dark = false, focusStyle = 'dot', wordFont = 'serif' }) {
  const parts = window.RSVPCore.splitForFocus(token || '');
  const fontSize = big ? 76 : 54;
  const focusColor = '#c96442';
  const inkColor = dark ? '#f5efe2' : '#1f1a17';
  const fontFamily = wordFont === 'serif'
    ? 'var(--font-serif)'
    : wordFont === 'mono'
      ? 'var(--font-mono)'
      : 'var(--font-sans)';

  return (
    <div style={{
      position: 'relative',
      width: '100%',
      minHeight: big ? 220 : 180,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      {/* Focus guides */}
      {focusStyle === 'crosshair' && (
        <>
          <div style={{ position: 'absolute', top: 12, bottom: 12, left: '50%', width: 0.5, background: dark ? 'rgba(245,239,226,0.18)' : 'rgba(31,26,23,0.15)' }}/>
          <div style={{ position: 'absolute', top: '50%', left: 24, right: 24, height: 0.5, background: dark ? 'rgba(245,239,226,0.08)' : 'rgba(31,26,23,0.08)' }}/>
        </>
      )}
      {focusStyle === 'line' && (
        <div style={{ position: 'absolute', top: 12, bottom: 12, left: '50%', width: 0.5, background: dark ? 'rgba(201,100,66,0.55)' : 'rgba(201,100,66,0.4)' }}/>
      )}
      {focusStyle === 'dot' && (
        <>
          <div style={{ position: 'absolute', top: 22, left: '50%', transform: 'translateX(-50%)', width: 4, height: 4, borderRadius: '50%', background: focusColor }}/>
          <div style={{ position: 'absolute', bottom: 22, left: '50%', transform: 'translateX(-50%)', width: 4, height: 4, borderRadius: '50%', background: focusColor }}/>
        </>
      )}

      <div style={{
        display: 'flex', alignItems: 'baseline', justifyContent: 'center',
        width: '100%',
        fontFamily, fontSize, fontWeight: wordFont === 'mono' ? 500 : 500,
        letterSpacing: -0.5, lineHeight: 1,
      }}>
        <div style={{
          flex: 1, textAlign: 'right', color: inkColor, paddingRight: 0,
          overflow: 'hidden', whiteSpace: 'nowrap',
        }}>{parts.before}</div>
        <div style={{ color: focusColor, fontWeight: 600 }}>{parts.focus}</div>
        <div style={{
          flex: 1, textAlign: 'left', color: inkColor, paddingLeft: 0,
          overflow: 'hidden', whiteSpace: 'nowrap',
        }}>{parts.after}</div>
      </div>
    </div>
  );
}

// ─── Reader Screen ───────────────────────────────────────────
function ReaderScreen({ wpm, setWpm, punctPause, focusStyle, wordFont, onFocusMode, onBack }) {
  const data = window.RSVPData.current;
  const tokens = useMemo(() => window.RSVPCore.tokenize(data.text), [data.text]);
  const [index, setIndex] = useState(Math.floor(tokens.length * 0.34));
  const [playing, setPlaying] = useState(false);
  const token = tokens[index] || '';
  const progress = tokens.length ? (index + 1) / tokens.length : 0;

  useEffect(() => {
    if (!playing) return;
    const dur = window.RSVPCore.durationForToken(token, wpm, punctPause);
    const t = setTimeout(() => {
      setIndex(i => {
        if (i >= tokens.length - 1) { setPlaying(false); return i; }
        return i + 1;
      });
    }, dur);
    return () => clearTimeout(t);
  }, [playing, token, index, wpm, punctPause, tokens.length]);

  const move = (d) => { setPlaying(false); setIndex(i => Math.max(0, Math.min(tokens.length - 1, i + d))); };
  const minutesLeft = window.RSVPCore.estimateMinutes(tokens.length - index, wpm);

  return (
    <div style={{ paddingBottom: 140, color: 'var(--ink)' }}>
      {/* Header w/ article meta */}
      <div style={{ padding: '60px 24px 16px' }}>
        <button onClick={onBack} style={{
          background: 'transparent', border: 0, padding: 0, cursor: 'pointer',
          fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.14em',
          textTransform: 'uppercase', color: 'var(--ink-quiet)',
          display: 'flex', alignItems: 'center', gap: 6,
        }}>
          <svg width="9" height="9" viewBox="0 0 9 9" fill="none"><path d="M5.5 1.5L2 4.5l3.5 3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>
          Library
        </button>
        <div style={{
          marginTop: 12,
          fontFamily: 'var(--font-serif)', fontSize: 22, lineHeight: 1.15,
          fontWeight: 500, letterSpacing: -0.4, color: 'var(--ink)',
          textWrap: 'pretty',
        }}>{data.title}</div>
        <div style={{
          marginTop: 8, fontFamily: 'var(--font-sans)', fontSize: 12,
          color: 'var(--ink-quiet)',
        }}>{data.source} · {data.author} · {data.date}</div>
      </div>

      {/* RSVP stage */}
      <div style={{ padding: '8px 16px' }}>
        <div style={{
          background: 'var(--paper-strong)', borderRadius: 4,
          border: '0.5px solid var(--rule)',
          padding: '20px 16px',
        }}>
          <RSVPStage token={token} focusStyle={focusStyle} wordFont={wordFont} />

          {/* Progress */}
          <div style={{ marginTop: 18, display: 'flex', flexDirection: 'column', gap: 8 }}>
            <div style={{
              position: 'relative', height: 2, background: 'var(--rule)', borderRadius: 2, overflow: 'hidden',
              cursor: 'pointer',
            }} onClick={(e) => {
              const rect = e.currentTarget.getBoundingClientRect();
              const pct = (e.clientX - rect.left) / rect.width;
              setPlaying(false);
              setIndex(Math.max(0, Math.min(tokens.length - 1, Math.floor(pct * tokens.length))));
            }}>
              <div style={{ width: `${progress * 100}%`, height: '100%', background: 'var(--terracotta)' }}/>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--ink-quiet)', letterSpacing: '0.06em' }}>
              <span>{index + 1} / {tokens.length}</span>
              <span>{minutesLeft < 1 ? `${Math.ceil(minutesLeft * 60)}s left` : `${minutesLeft.toFixed(1)}m left`}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Transport */}
      <div style={{
        marginTop: 18, padding: '0 24px',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 14,
      }}>
        <TransportButton ariaLabel="Back 10" onClick={() => move(-10)}>
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <path d="M9 3a6 6 0 106 6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
            <path d="M9 1L6 3l3 2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
            <text x="9" y="12" fontFamily="var(--font-mono)" fontSize="6" textAnchor="middle" fill="currentColor">10</text>
          </svg>
        </TransportButton>
        <TransportButton ariaLabel="Prev word" onClick={() => move(-1)}>
          <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor"><path d="M3 1h2v12H3zM13 1L5 7l8 6z"/></svg>
        </TransportButton>
        <button onClick={() => setPlaying(p => !p)} style={{
          width: 64, height: 64, borderRadius: '50%',
          background: 'var(--terracotta)', color: '#fff', border: 0,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer', boxShadow: '0 4px 14px rgba(201,100,66,0.32)',
        }}>
          {playing ? (
            <svg width="20" height="20" viewBox="0 0 20 20" fill="#fff"><rect x="4" y="3" width="4" height="14"/><rect x="12" y="3" width="4" height="14"/></svg>
          ) : (
            <svg width="20" height="20" viewBox="0 0 20 20" fill="#fff"><path d="M5 2v16l13-8z"/></svg>
          )}
        </button>
        <TransportButton ariaLabel="Next word" onClick={() => move(1)}>
          <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor"><path d="M9 1h2v12H9zM1 1l8 6-8 6z"/></svg>
        </TransportButton>
        <TransportButton ariaLabel="Focus mode" onClick={onFocusMode}>
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path d="M2 6V2h4M14 6V2h-4M2 10v4h4M14 10v4h-4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </TransportButton>
      </div>

      {/* WPM dial */}
      <div style={{ marginTop: 22, padding: '0 24px' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 8 }}>
          <SectionLabel>Pace</SectionLabel>
          <div style={{
            fontFamily: 'var(--font-serif)', fontSize: 22, fontWeight: 600,
            color: 'var(--ink)', fontVariantNumeric: 'tabular-nums',
          }}>{wpm} <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--ink-quiet)', letterSpacing: '0.14em', textTransform: 'uppercase' }}>wpm</span></div>
        </div>
        <input type="range" min={150} max={1000} step={25}
          value={wpm} onChange={e => setWpm(Number(e.target.value))}
          style={{ width: '100%', accentColor: '#c96442' }}
        />
        <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--ink-quiet)', letterSpacing: '0.06em', marginTop: 2 }}>
          <span>150</span><span>500</span><span>1000</span>
        </div>
      </div>

      {/* Inline preview text */}
      <div style={{ marginTop: 24, padding: '0 24px' }}>
        <SectionLabel style={{ marginBottom: 10 }}>The full text</SectionLabel>
        <div style={{
          fontFamily: 'var(--font-serif)', fontSize: 15.5, lineHeight: 1.55,
          color: 'var(--ink-mid)', textWrap: 'pretty',
        }}>
          {tokens.map((t, i) => {
            const p = window.RSVPCore.splitForFocus(t);
            const isCurrent = i === index;
            const isRead = i < index;
            return (
              <span key={i} style={{
                background: isCurrent ? 'rgba(201,100,66,0.12)' : 'transparent',
                color: isRead ? 'var(--ink-quiet)' : isCurrent ? 'var(--ink)' : 'var(--ink-mid)',
                fontWeight: isCurrent ? 600 : 400,
                padding: isCurrent ? '0 2px' : 0,
                borderRadius: 2,
              }}>
                {p.before}
                <span style={{ color: 'var(--terracotta)', fontWeight: 600 }}>{p.focus}</span>
                {p.after}{' '}
              </span>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function TransportButton({ children, onClick, ariaLabel }) {
  return (
    <button aria-label={ariaLabel} onClick={onClick} style={{
      width: 44, height: 44, borderRadius: '50%',
      background: 'transparent', border: '0.5px solid var(--rule-strong)',
      color: 'var(--ink)', cursor: 'pointer',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>{children}</button>
  );
}

// ─── Focus Mode (fullscreen) ─────────────────────────────────
function FocusMode({ wpm, punctPause, focusStyle, wordFont, onClose }) {
  const data = window.RSVPData.current;
  const tokens = useMemo(() => window.RSVPCore.tokenize(data.text), [data.text]);
  const [index, setIndex] = useState(Math.floor(tokens.length * 0.34));
  const [playing, setPlaying] = useState(true);
  const token = tokens[index] || '';
  const progress = tokens.length ? (index + 1) / tokens.length : 0;

  useEffect(() => {
    if (!playing) return;
    const dur = window.RSVPCore.durationForToken(token, wpm, punctPause);
    const t = setTimeout(() => {
      setIndex(i => {
        if (i >= tokens.length - 1) { setPlaying(false); return i; }
        return i + 1;
      });
    }, dur);
    return () => clearTimeout(t);
  }, [playing, token, index, wpm, punctPause, tokens.length]);

  const move = (d) => { setPlaying(false); setIndex(i => Math.max(0, Math.min(tokens.length - 1, i + d))); };

  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 100,
      background: '#1c1714', color: '#f5efe2',
      display: 'flex', flexDirection: 'column',
      paddingTop: 56, paddingBottom: 40,
    }}>
      {/* Top: meta + close */}
      <div style={{ padding: '0 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{
            fontFamily: 'var(--font-mono)', fontSize: 10, letterSpacing: '0.14em',
            color: 'rgba(245,239,226,0.5)', textTransform: 'uppercase',
          }}>Focus · {wpm} wpm</div>
          <div style={{
            fontFamily: 'var(--font-serif)', fontSize: 14, color: 'rgba(245,239,226,0.85)',
            marginTop: 4, lineHeight: 1.3, maxWidth: 260,
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
          }}>{data.title}</div>
        </div>
        <button onClick={onClose} style={{
          width: 40, height: 40, borderRadius: '50%',
          background: 'rgba(245,239,226,0.1)', color: '#f5efe2', border: 0,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer',
        }}>
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M2 2l10 10M12 2L2 12" stroke="#f5efe2" strokeWidth="1.5" strokeLinecap="round"/></svg>
        </button>
      </div>

      {/* Big stage */}
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 12px' }}>
        <RSVPStage token={token} big dark focusStyle={focusStyle} wordFont={wordFont} />
      </div>

      {/* Bottom: progress + transport */}
      <div style={{ padding: '0 24px', display: 'flex', flexDirection: 'column', gap: 18 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <div style={{ height: 2, background: 'rgba(245,239,226,0.15)', borderRadius: 2, overflow: 'hidden' }}>
            <div style={{ width: `${progress * 100}%`, height: '100%', background: 'var(--terracotta)' }}/>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'var(--font-mono)', fontSize: 10, color: 'rgba(245,239,226,0.5)', letterSpacing: '0.06em' }}>
            <span>{index + 1} / {tokens.length}</span>
            <span>{Math.round(progress * 100)}%</span>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 14 }}>
          <DarkTransport onClick={() => move(-10)}>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor"><path d="M1 1h2v12H1zM13 1L5 7l8 6z"/></svg>
          </DarkTransport>
          <DarkTransport onClick={() => move(-1)} small>
            <svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor"><path d="M1 1h2v8H1zM9 1L4 5l5 4z"/></svg>
          </DarkTransport>
          <button onClick={() => setPlaying(p => !p)} style={{
            width: 72, height: 72, borderRadius: '50%',
            background: 'var(--terracotta)', color: '#fff', border: 0,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: 'pointer',
          }}>
            {playing ? (
              <svg width="22" height="22" viewBox="0 0 22 22" fill="#fff"><rect x="5" y="3" width="4" height="16"/><rect x="13" y="3" width="4" height="16"/></svg>
            ) : (
              <svg width="22" height="22" viewBox="0 0 22 22" fill="#fff"><path d="M5 2v18l15-9z"/></svg>
            )}
          </button>
          <DarkTransport onClick={() => move(1)} small>
            <svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor"><path d="M7 1h2v8H7zM1 1l5 4-5 4z"/></svg>
          </DarkTransport>
          <DarkTransport onClick={() => move(10)}>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor"><path d="M11 1h2v12h-2zM1 1l8 6-8 6z"/></svg>
          </DarkTransport>
        </div>
      </div>
    </div>
  );
}

function DarkTransport({ children, onClick, small }) {
  const s = small ? 40 : 48;
  return (
    <button onClick={onClick} style={{
      width: s, height: s, borderRadius: '50%',
      background: 'rgba(245,239,226,0.08)', color: '#f5efe2', border: 0,
      display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
    }}>{children}</button>
  );
}

// ─── Settings ────────────────────────────────────────────────
function SettingsScreen({ wpm, setWpm, punctPause, setPunctPause, focusStyle, setFocusStyle, wordFont, setWordFont }) {
  return (
    <div style={{ paddingBottom: 140, color: 'var(--ink)' }}>
      <div style={{ padding: '60px 24px 18px' }}>
        <SectionLabel>Settings</SectionLabel>
        <div style={{
          marginTop: 8,
          fontFamily: 'var(--font-serif)', fontSize: 36, lineHeight: 1.05,
          fontWeight: 500, letterSpacing: -0.9, color: 'var(--ink)',
        }}>The shape<br/>of your read.</div>
      </div>

      <div style={{ padding: '0 16px' }}>
        <SettingsGroup label="Pace">
          <SettingsRow>
            <div style={{ fontFamily: 'var(--font-sans)', fontSize: 15 }}>Words per minute</div>
            <div style={{
              fontFamily: 'var(--font-serif)', fontSize: 18, fontWeight: 600,
              fontVariantNumeric: 'tabular-nums',
            }}>{wpm}</div>
          </SettingsRow>
          <div style={{ padding: '0 16px 14px' }}>
            <input type="range" min={150} max={1000} step={25}
              value={wpm} onChange={e => setWpm(Number(e.target.value))}
              style={{ width: '100%', accentColor: '#c96442' }}/>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--ink-quiet)', letterSpacing: '0.06em', marginTop: 2 }}>
              <span>Slow · 150</span><span>Comfortable · 500</span><span>Sprint · 1000</span>
            </div>
          </div>
          <SettingsRow last>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 15 }}>Pause on punctuation</div>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: 'var(--ink-quiet)', marginTop: 2 }}>Slows down at periods, commas, and semicolons.</div>
            </div>
            <Toggle on={punctPause} onChange={setPunctPause} />
          </SettingsRow>
        </SettingsGroup>

        <SettingsGroup label="Focus indicator">
          <Segmented
            value={focusStyle} onChange={setFocusStyle}
            options={[
              { id: 'dot', label: 'Dots' },
              { id: 'line', label: 'Line' },
              { id: 'crosshair', label: 'Crosshair' },
            ]}
          />
        </SettingsGroup>

        <SettingsGroup label="Word typeface">
          <Segmented
            value={wordFont} onChange={setWordFont}
            options={[
              { id: 'serif', label: 'Serif' },
              { id: 'sans', label: 'Sans' },
              { id: 'mono', label: 'Mono' },
            ]}
          />
        </SettingsGroup>

        <SettingsGroup label="About">
          <SettingsRow><div>Version</div><div style={{ color: 'var(--ink-quiet)', fontFamily: 'var(--font-mono)', fontSize: 13 }}>1.4.0</div></SettingsRow>
          <SettingsRow><div>Privacy policy</div><Chevron/></SettingsRow>
          <SettingsRow last><div>Send feedback</div><Chevron/></SettingsRow>
        </SettingsGroup>
      </div>
    </div>
  );
}

function SettingsGroup({ label, children }) {
  return (
    <div style={{ marginBottom: 22 }}>
      <SectionLabel style={{ padding: '0 8px 8px' }}>{label}</SectionLabel>
      <div style={{
        background: 'var(--paper-strong)', borderRadius: 4,
        border: '0.5px solid var(--rule)', overflow: 'hidden',
      }}>{children}</div>
    </div>
  );
}
function SettingsRow({ children, last }) {
  return (
    <div style={{
      padding: '14px 16px', minHeight: 52,
      borderBottom: last ? 0 : '0.5px solid var(--rule)',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      gap: 14, fontFamily: 'var(--font-sans)', fontSize: 15, color: 'var(--ink)',
    }}>{children}</div>
  );
}
function Chevron() {
  return <svg width="7" height="11" viewBox="0 0 7 11" fill="none"><path d="M1 1l5 4.5L1 10" stroke="var(--ink-quiet)" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>;
}
function Toggle({ on, onChange }) {
  return (
    <button onClick={() => onChange(!on)} style={{
      width: 44, height: 26, borderRadius: 999,
      background: on ? 'var(--terracotta)' : 'var(--rule-strong)',
      border: 0, cursor: 'pointer', position: 'relative',
      transition: 'background 0.18s',
    }}>
      <div style={{
        position: 'absolute', top: 2, left: on ? 20 : 2,
        width: 22, height: 22, borderRadius: '50%', background: '#fff',
        boxShadow: '0 1px 3px rgba(0,0,0,0.15)',
        transition: 'left 0.18s',
      }}/>
    </button>
  );
}
function Segmented({ value, onChange, options }) {
  return (
    <div style={{
      display: 'flex', padding: 4, gap: 4,
      background: 'var(--paper-strong)',
    }}>
      {options.map(o => {
        const on = value === o.id;
        return (
          <button key={o.id} onClick={() => onChange(o.id)} style={{
            flex: 1, padding: '10px 8px', borderRadius: 3,
            background: on ? 'var(--ink)' : 'transparent',
            color: on ? 'var(--paper)' : 'var(--ink-mid)', border: 0,
            fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: on ? 600 : 500,
            cursor: 'pointer', letterSpacing: -0.1,
          }}>{o.label}</button>
        );
      })}
    </div>
  );
}

// ─── Stats ───────────────────────────────────────────────────
function StatsScreen() {
  const s = window.RSVPData.stats;
  const max = Math.max(...s.week.map(d => d.words));
  return (
    <div style={{ paddingBottom: 140, color: 'var(--ink)' }}>
      <div style={{ padding: '60px 24px 18px' }}>
        <SectionLabel>This week</SectionLabel>
        <div style={{
          marginTop: 8,
          fontFamily: 'var(--font-serif)', fontSize: 36, lineHeight: 1.05,
          fontWeight: 500, letterSpacing: -0.9, color: 'var(--ink)',
        }}>{s.week.reduce((a,d)=>a+d.words,0).toLocaleString()} <span style={{ color: 'var(--ink-quiet)', fontWeight: 400 }}>words</span></div>
        <div style={{
          marginTop: 8, fontFamily: 'var(--font-sans)', fontSize: 14,
          color: 'var(--ink-mid)', lineHeight: 1.5,
        }}>That's roughly {Math.round(s.week.reduce((a,d)=>a+d.words,0) / 60000 * 100)/100} novellas at {s.avgWpm} wpm.</div>
      </div>

      <div style={{ padding: '0 16px' }}>
        {/* Bar chart */}
        <div style={{
          background: 'var(--paper-strong)', borderRadius: 4,
          border: '0.5px solid var(--rule)', padding: 18,
        }}>
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 10, height: 130 }}>
            {s.week.map((d, i) => {
              const isToday = i === s.week.length - 1;
              return (
                <div key={d.day} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
                  <div style={{
                    width: '100%', height: `${(d.words / max) * 100}%`,
                    background: isToday ? 'var(--terracotta)' : 'var(--ink)',
                    minHeight: 4, borderRadius: 1,
                    opacity: isToday ? 1 : 0.78,
                  }}/>
                  <div style={{
                    fontFamily: 'var(--font-mono)', fontSize: 10, letterSpacing: '0.06em',
                    color: isToday ? 'var(--terracotta)' : 'var(--ink-quiet)',
                    textTransform: 'uppercase', fontWeight: isToday ? 600 : 400,
                  }}>{d.day}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Stat grid */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginTop: 8 }}>
          <StatCard label="Streak" value={s.streak} unit="days"/>
          <StatCard label="Avg pace" value={s.avgWpm} unit="wpm"/>
          <StatCard label="Best pace" value={s.bestWpm} unit="wpm"/>
          <StatCard label="Articles read" value={s.totalArticles} unit="total"/>
        </div>

        {/* Editorial note */}
        <div style={{
          marginTop: 24, padding: '20px 18px',
          background: 'var(--paper-strong)', borderRadius: 4,
          border: '0.5px solid var(--rule)',
          borderLeft: '3px solid var(--terracotta)',
        }}>
          <SectionLabel>This week's note</SectionLabel>
          <div style={{
            marginTop: 10, fontFamily: 'var(--font-serif)', fontSize: 16, lineHeight: 1.45,
            color: 'var(--ink)', textWrap: 'pretty',
          }}>
            You're reading 18% faster than last week, but pausing more often on punctuation. That's usually a sign you're picking denser writing — keep going.
          </div>
        </div>
      </div>
    </div>
  );
}
function StatCard({ label, value, unit }) {
  return (
    <div style={{
      background: 'var(--paper-strong)', borderRadius: 4,
      border: '0.5px solid var(--rule)',
      padding: '14px 14px 16px',
    }}>
      <SectionLabel>{label}</SectionLabel>
      <div style={{
        marginTop: 10, fontFamily: 'var(--font-serif)', fontSize: 30,
        fontWeight: 500, color: 'var(--ink)', letterSpacing: -0.5,
        fontVariantNumeric: 'tabular-nums', lineHeight: 1,
      }}>{value}</div>
      <div style={{
        marginTop: 4, fontFamily: 'var(--font-mono)', fontSize: 10,
        color: 'var(--ink-quiet)', letterSpacing: '0.14em', textTransform: 'uppercase',
      }}>{unit}</div>
    </div>
  );
}

// Export everything
Object.assign(window, {
  JustReadIcon, SectionLabel, JustReadTabBar,
  HomeScreen, SourceScreen, ReaderScreen, FocusMode, SettingsScreen, StatsScreen,
});
