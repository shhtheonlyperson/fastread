// ZenCard — visual representation of an Osho-style zen card.
// Two-sided: face-down (Zen sigil) and face-up (color field + glyph + name).

function ZenCardBack({ width = 120, ratio = 1.55, style = {} }) {
  const h = width * ratio;
  return (
    <div style={{
      width, height: h, borderRadius: 10, overflow: 'hidden',
      background: 'linear-gradient(160deg, #1a1612 0%, #221b14 60%, #2a2018 100%)',
      boxShadow: '0 1px 0 rgba(255,255,255,0.04) inset, 0 0 0 1px rgba(184,153,104,0.25), 0 8px 22px rgba(0,0,0,0.35)',
      position: 'relative',
      ...style,
    }}>
      {/* inner frame */}
      <div style={{
        position: 'absolute', inset: 6, borderRadius: 6,
        border: '0.5px solid rgba(184,153,104,0.45)',
      }} />
      {/* sigil */}
      <div style={{
        position: 'absolute', inset: 0, display: 'flex',
        alignItems: 'center', justifyContent: 'center', flexDirection: 'column',
        gap: width * 0.04,
      }}>
        <svg width={width * 0.42} height={width * 0.42} viewBox="0 0 100 100" style={{ opacity: 0.85 }}>
          <circle cx="50" cy="50" r="34" fill="none" stroke="#B89968" strokeWidth="0.8"/>
          <circle cx="50" cy="50" r="22" fill="none" stroke="#B89968" strokeWidth="0.5"/>
          <circle cx="50" cy="50" r="10" fill="#B89968" fillOpacity="0.18"/>
          <path d="M50 8 L50 28 M50 72 L50 92 M8 50 L28 50 M72 50 L92 50"
                stroke="#B89968" strokeWidth="0.6" />
          <circle cx="50" cy="50" r="3" fill="#B89968"/>
        </svg>
        <div className="serif" style={{
          fontSize: width * 0.13, color: '#B89968', letterSpacing: '0.22em',
          fontStyle: 'italic',
        }}>zen</div>
      </div>
      {/* corners */}
      {[0,1,2,3].map(i => (
        <div key={i} style={{
          position: 'absolute', width: 7, height: 7,
          top: i < 2 ? 3 : 'auto', bottom: i >= 2 ? 3 : 'auto',
          left: i % 2 === 0 ? 3 : 'auto', right: i % 2 === 1 ? 3 : 'auto',
          borderTop: i < 2 ? '0.5px solid rgba(184,153,104,0.55)' : 'none',
          borderBottom: i >= 2 ? '0.5px solid rgba(184,153,104,0.55)' : 'none',
          borderLeft: i % 2 === 0 ? '0.5px solid rgba(184,153,104,0.55)' : 'none',
          borderRight: i % 2 === 1 ? '0.5px solid rgba(184,153,104,0.55)' : 'none',
        }}/>
      ))}
    </div>
  );
}

function ZenCardFace({ card, width = 120, ratio = 1.55, style = {} }) {
  const h = width * ratio;
  if (!card) return <ZenCardBack width={width} ratio={ratio} style={style}/>;
  return (
    <div style={{
      width, height: h, borderRadius: 10, overflow: 'hidden',
      background: '#FAF7F2',
      boxShadow: '0 0 0 1px rgba(0,0,0,0.06), 0 8px 22px rgba(0,0,0,0.18)',
      position: 'relative', display: 'flex', flexDirection: 'column',
      ...style,
    }}>
      {/* color field — abstract painted scene */}
      <div style={{
        height: '62%', position: 'relative', overflow: 'hidden',
        background: `linear-gradient(160deg, ${card.color} 0%, ${card.color}dd 50%, ${card.color}88 100%)`,
      }}>
        {/* horizon wash */}
        <div style={{
          position: 'absolute', left: 0, right: 0, bottom: 0, height: '40%',
          background: `linear-gradient(180deg, transparent 0%, rgba(0,0,0,0.18) 100%)`,
        }} />
        {/* glyph */}
        <div style={{
          position: 'absolute', inset: 0, display: 'flex',
          alignItems: 'center', justifyContent: 'center',
          fontSize: width * 0.4, color: 'rgba(255,255,255,0.85)',
          textShadow: '0 1px 12px rgba(0,0,0,0.25)',
          fontFamily: 'var(--f-serif)',
        }}>{card.glyph}</div>
        {/* number */}
        <div className="mono" style={{
          position: 'absolute', top: 8, left: 9, color: 'rgba(255,255,255,0.78)',
          fontSize: width * 0.075, letterSpacing: '0.1em',
        }}>{String(card.num).padStart(2,'0')}</div>
        <div className="mono" style={{
          position: 'absolute', top: 8, right: 9, color: 'rgba(255,255,255,0.78)',
          fontSize: width * 0.075, letterSpacing: '0.12em', textTransform: 'uppercase',
        }}>{card.suit.slice(0,3)}</div>
      </div>
      {/* caption */}
      <div style={{
        flex: 1, display: 'flex', flexDirection: 'column',
        justifyContent: 'center', alignItems: 'center',
        padding: `${width*0.06}px ${width*0.06}px`,
        textAlign: 'center', gap: width * 0.02,
      }}>
        <div className="serif" style={{
          fontSize: width * 0.13, color: '#1F1B16', lineHeight: 1.05,
          fontWeight: 500,
        }}>{card.name}</div>
        <div className="serif" style={{
          fontSize: width * 0.085, color: '#8B7F70', fontStyle: 'italic',
          letterSpacing: '0.04em',
        }}>{card.zh}</div>
      </div>
    </div>
  );
}

// Flippable card
function ZenCard({ card, faceUp, width = 120, onClick, style = {}, delay = 0 }) {
  const h = width * 1.55;
  return (
    <div onClick={onClick} style={{
      width, height: h, perspective: 1000, cursor: onClick ? 'pointer' : 'default',
      ...style,
    }}>
      <div style={{
        width: '100%', height: '100%', position: 'relative',
        transformStyle: 'preserve-3d',
        transition: 'transform 0.7s cubic-bezier(0.4, 0.1, 0.2, 1)',
        transitionDelay: `${delay}ms`,
        transform: faceUp ? 'rotateY(180deg)' : 'rotateY(0deg)',
      }}>
        <div style={{ position: 'absolute', inset: 0, backfaceVisibility: 'hidden' }}>
          <ZenCardBack width={width} />
        </div>
        <div style={{
          position: 'absolute', inset: 0, backfaceVisibility: 'hidden',
          transform: 'rotateY(180deg)',
        }}>
          <ZenCardFace card={card} width={width}/>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ZenCardBack, ZenCardFace, ZenCard });
