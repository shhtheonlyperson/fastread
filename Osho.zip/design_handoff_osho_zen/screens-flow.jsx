// Spreads list, instructions, shuffling and drawing screens

function SpreadsScreen({ goBack, goSpread }) {
  return (
    <Screen>
      <NavBar title="Spreads" onBack={goBack}/>
      <div className="scroll-y" style={{ flex: 1, padding: '8px 24px 100px' }}>
        <div style={{ padding: '4px 0 20px' }}>
          <div className="serif" style={{ fontSize: 32, fontStyle: 'italic', color: 'var(--c-ink)', letterSpacing: '-0.02em', lineHeight: 1.05 }}>
            Five ways<br/>
            <span style={{ fontStyle: 'normal' }}>to listen.</span>
          </div>
          <div className="serif" style={{ fontSize: 14, color: 'var(--c-ink-2)', marginTop: 10, lineHeight: 1.5 }}>
            Each spread holds a different question gently. Pick one — or let one pick you.
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {window.OSHO_SPREADS.map(s => (
            <button key={s.id} onClick={() => goSpread(s.id)} style={{
              background: 'var(--c-paper)', border: '0.5px solid var(--c-line)',
              borderRadius: 16, padding: '18px 18px 16px', cursor: 'pointer', textAlign: 'left',
              display: 'flex', gap: 16, alignItems: 'center',
            }}>
              <div style={{
                width: 64, height: 64, borderRadius: 12, background: 'var(--c-canvas)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                border: '0.5px solid var(--c-line)',
              }}>
                <SpreadDiagram spread={s} size={48}/>
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 2 }}>
                  <div className="serif" style={{ fontSize: 19, color: 'var(--c-ink)', fontWeight: 500 }}>{s.name}</div>
                  <div className="serif" style={{ fontSize: 12.5, color: 'var(--c-mute)', fontStyle: 'italic' }}>{s.zh}</div>
                </div>
                <div className="serif" style={{ fontSize: 13, color: 'var(--c-ink-2)', fontStyle: 'italic', lineHeight: 1.4 }}>
                  {s.tagline}
                </div>
                <div className="mono" style={{ fontSize: 9.5, letterSpacing: '0.16em', color: 'var(--c-clay)', marginTop: 8, fontWeight: 600 }}>
                  {String(s.count).padStart(2,'0')} CARDS
                </div>
              </div>
              {I.arrow('#8B7F70')}
            </button>
          ))}
        </div>

        {/* Instructions card */}
        <button style={{
          marginTop: 14, width: '100%', padding: '18px 18px',
          background: 'var(--c-zen-night)', color: '#FAF7F2',
          borderRadius: 16, border: 'none', cursor: 'pointer',
          display: 'flex', alignItems: 'center', gap: 14, textAlign: 'left',
        }}>
          <div style={{ width: 38, height: 38, borderRadius: 10, border: '0.5px solid #B89968', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#B89968', fontFamily: 'var(--f-serif)', fontSize: 18 }}>禪</div>
          <div style={{ flex: 1 }}>
            <div className="mono" style={{ fontSize: 9.5, letterSpacing: '0.18em', color: '#B89968' }}>GUIDE · 使用說明</div>
            <div className="serif" style={{ fontSize: 16, marginTop: 4 }}>How to use the cards</div>
          </div>
          {I.arrow('#FAF7F2')}
        </button>
      </div>
    </Screen>
  );
}

// ─────────── Spread detail / question entry ───────────
function SpreadDetailScreen({ spread, goBack, onBegin }) {
  const [question, setQuestion] = useState('');
  return (
    <Screen>
      <NavBar title={spread.name} onBack={goBack}/>
      <div className="scroll-y" style={{ flex: 1, padding: '8px 24px 24px' }}>
        <div style={{ display: 'flex', justifyContent: 'center', padding: '12px 0 8px' }}>
          <div style={{ width: 130, height: 130, borderRadius: '50%', background: 'var(--c-paper)', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '0.5px solid var(--c-line)' }}>
            <SpreadDiagram spread={spread} size={88}/>
          </div>
        </div>

        <div style={{ textAlign: 'center', padding: '12px 0 6px' }}>
          <div className="mono" style={{ fontSize: 10, letterSpacing: '0.2em', color: 'var(--c-clay)', fontWeight: 600 }}>
            {String(spread.count).padStart(2,'0')} CARDS · {spread.zh}
          </div>
          <div className="serif" style={{ fontSize: 30, fontStyle: 'italic', color: 'var(--c-ink)', marginTop: 6, letterSpacing: '-0.01em' }}>
            {spread.name}
          </div>
          <div className="serif" style={{ fontSize: 14, color: 'var(--c-ink-2)', marginTop: 8, lineHeight: 1.5, padding: '0 4px' }}>
            {spread.desc}
          </div>
        </div>

        {/* positions */}
        <div style={{ marginTop: 22 }}>
          <div className="eyebrow" style={{ marginBottom: 10 }}>Positions</div>
          <div style={{ display: 'grid', gridTemplateColumns: spread.count > 6 ? '1fr 1fr 1fr' : '1fr 1fr', gap: 8 }}>
            {spread.positions.map((p, i) => (
              <div key={i} style={{
                padding: '10px 10px', background: 'var(--c-paper)', borderRadius: 10,
                border: '0.5px solid var(--c-line)', display: 'flex', gap: 8, alignItems: 'center',
              }}>
                <div className="mono" style={{
                  fontSize: 9, letterSpacing: '0.1em', color: 'var(--c-clay)',
                  width: 16, height: 16, borderRadius: '50%', background: 'var(--c-clay-wash)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700,
                }}>{i+1}</div>
                <div className="serif" style={{ fontSize: 12.5, color: 'var(--c-ink)' }}>{p}</div>
              </div>
            ))}
          </div>
        </div>

        {/* question */}
        <div style={{ marginTop: 22 }}>
          <div className="eyebrow" style={{ marginBottom: 8 }}>Your question (optional)</div>
          <textarea
            value={question}
            onChange={e => setQuestion(e.target.value)}
            placeholder="Hold a question gently in your mind, or leave blank for an open reading…"
            style={{
              width: '100%', minHeight: 88, padding: 14, borderRadius: 12,
              border: '0.5px solid var(--c-line)', background: 'var(--c-paper)',
              fontFamily: 'var(--f-serif)', fontSize: 14.5, lineHeight: 1.5,
              color: 'var(--c-ink)', resize: 'none', outline: 'none',
            }}
          />
        </div>

        {/* Begin button */}
        <button onClick={() => onBegin(question)} style={{
          marginTop: 18, width: '100%', padding: '16px',
          background: 'var(--c-clay)', color: '#FAF7F2', border: 'none',
          borderRadius: 14, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
          fontFamily: 'var(--f-sans)', fontSize: 15.5, fontWeight: 500, letterSpacing: '0.01em',
          boxShadow: '0 1px 0 rgba(255,255,255,0.18) inset, 0 8px 22px rgba(201,100,66,0.22)',
        }}>
          {I.shuffle()}
          Begin shuffling
        </button>

        <div className="serif" style={{ fontSize: 12, color: 'var(--c-mute)', textAlign: 'center', marginTop: 14, fontStyle: 'italic', padding: '0 18px' }}>
          Find a quiet spot. Settle the breath. The cards do not predict — they reflect.
        </div>
      </div>
    </Screen>
  );
}

// ─────────── Shuffling screen ───────────
function ShuffleScreen({ spread, question, goBack, onReady }) {
  const [phase, setPhase] = useState('shuffle'); // shuffle -> ready
  const [shuffleProgress, setShuffleProgress] = useState(0);

  useEffect(() => {
    if (phase !== 'shuffle') return;
    const id = setInterval(() => {
      setShuffleProgress(p => {
        const next = p + 1;
        if (next >= 100) { clearInterval(id); setPhase('ready'); return 100; }
        return next;
      });
    }, 32);
    return () => clearInterval(id);
  }, [phase]);

  return (
    <Screen bg="var(--c-zen-night)">
      <NavBar title="" onBack={goBack} dark transparent/>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '0 24px 32px', color: '#FAF7F2' }}>
        <div style={{ textAlign: 'center', padding: '0 0 24px' }}>
          <div className="mono" style={{ fontSize: 10, letterSpacing: '0.22em', color: '#B89968' }}>
            {phase === 'shuffle' ? 'SHUFFLING · 洗牌' : 'READY · 準備就緒'}
          </div>
          <div className="serif" style={{ fontSize: 26, fontStyle: 'italic', color: '#FAF7F2', marginTop: 8 }}>
            {phase === 'shuffle' ? 'Pour your energy in.' : 'Cut the deck when you\'re ready.'}
          </div>
          {question && (
            <div className="serif" style={{
              marginTop: 14, fontSize: 13, color: 'rgba(250,247,242,0.65)', fontStyle: 'italic',
              borderLeft: '1px solid #B89968', paddingLeft: 12, textAlign: 'left',
              maxWidth: 280, marginLeft: 'auto', marginRight: 'auto',
            }}>"{question}"</div>
          )}
        </div>

        {/* Card stack visualization */}
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
          <ShuffleStack shuffling={phase === 'shuffle'}/>
        </div>

        {/* Bottom controls */}
        <div style={{ paddingTop: 16 }}>
          {phase === 'shuffle' ? (
            <>
              <div style={{ height: 2, background: 'rgba(184,153,104,0.2)', borderRadius: 99, overflow: 'hidden', marginBottom: 14 }}>
                <div style={{ height: '100%', width: `${shuffleProgress}%`, background: '#B89968', transition: 'width 32ms linear' }}/>
              </div>
              <button onClick={() => setPhase('ready')} style={{
                width: '100%', padding: '15px', background: 'transparent',
                border: '0.5px solid rgba(184,153,104,0.4)', borderRadius: 14, color: '#B89968',
                fontSize: 14, fontWeight: 500, cursor: 'pointer', letterSpacing: '0.04em',
              }}>SKIP SHUFFLE</button>
            </>
          ) : (
            <button onClick={onReady} style={{
              width: '100%', padding: '17px', background: '#C96442', color: '#FAF7F2',
              border: 'none', borderRadius: 14, cursor: 'pointer',
              fontSize: 15.5, fontWeight: 500, letterSpacing: '0.01em',
              boxShadow: '0 8px 22px rgba(201,100,66,0.28)',
            }}>Cut the deck →</button>
          )}
        </div>
      </div>
    </Screen>
  );
}

function ShuffleStack({ shuffling }) {
  return (
    <div style={{ position: 'relative', width: 220, height: 280 }}>
      {[0,1,2,3,4].map(i => (
        <div key={i} style={{
          position: 'absolute', left: '50%', top: '50%',
          marginLeft: -65, marginTop: -100,
          animation: shuffling ? `shuf ${1.2 + i*0.15}s ease-in-out infinite` : 'none',
          animationDelay: `${i * 0.08}s`,
          transform: `rotate(${(i - 2) * 3}deg) translate(${(i - 2) * 4}px, 0)`,
        }}>
          <ZenCardBack width={130}/>
        </div>
      ))}
      {/* glow */}
      <div style={{
        position: 'absolute', left: '50%', top: '50%',
        width: 260, height: 260, marginLeft: -130, marginTop: -130,
        borderRadius: '50%', background: 'radial-gradient(circle, rgba(184,153,104,0.18) 0%, transparent 60%)',
        animation: 'glow 3s ease-in-out infinite', pointerEvents: 'none',
      }}/>
    </div>
  );
}

// ─────────── Card draw screen — fan the deck, tap to draw ───────────
function DrawScreen({ spread, question, goBack, onComplete }) {
  // Pre-shuffle the available card pool
  const deck = useMemo(() => {
    const arr = [...window.OSHO_CARDS];
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr.slice(0, 30); // fan of 30
  }, []);

  const [drawn, setDrawn] = useState([]); // array of card ids in order

  function drawCard(idx) {
    if (drawn.length >= spread.count) return;
    if (drawn.find(d => d.deckIdx === idx)) return;
    const card = deck[idx];
    const next = [...drawn, { deckIdx: idx, cardId: card.id }];
    setDrawn(next);
    if (next.length === spread.count) {
      setTimeout(() => onComplete(next), 800);
    }
  }

  return (
    <Screen bg="var(--c-zen-night)">
      <NavBar title="" onBack={goBack} dark transparent right={
        <div className="mono" style={{ fontSize: 11, color: '#B89968', letterSpacing: '0.1em' }}>
          {drawn.length}/{spread.count}
        </div>
      }/>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', color: '#FAF7F2' }}>
        <div style={{ textAlign: 'center', padding: '0 24px 8px' }}>
          <div className="mono" style={{ fontSize: 10, letterSpacing: '0.22em', color: '#B89968' }}>
            DRAWING · {spread.zh}
          </div>
          <div className="serif" style={{ fontSize: 22, fontStyle: 'italic', marginTop: 6 }}>
            {drawn.length < spread.count
              ? <>Choose <span style={{ color: '#C96442', fontStyle: 'normal' }}>{spread.positions[drawn.length]}</span></>
              : 'All drawn.'}
          </div>
          <div className="serif" style={{ fontSize: 12.5, color: 'rgba(250,247,242,0.55)', marginTop: 4, fontStyle: 'italic' }}>
            Tap a card with your left hand
          </div>
        </div>

        {/* Drawn slots preview */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: 6, padding: '14px 16px 8px', flexWrap: 'wrap' }}>
          {spread.positions.map((p, i) => {
            const d = drawn[i];
            const card = d ? window.OSHO_CARDS.find(k => k.id === d.cardId) : null;
            return (
              <div key={i} style={{
                width: 36, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
                opacity: i === drawn.length ? 1 : 0.6,
              }}>
                <div style={{
                  width: 28, height: 42, borderRadius: 4,
                  background: card ? `linear-gradient(160deg, ${card.color} 0%, ${card.color}88 100%)` : 'rgba(184,153,104,0.12)',
                  border: card ? 'none' : '0.5px dashed rgba(184,153,104,0.4)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontFamily: 'var(--f-serif)', color: card ? 'rgba(255,255,255,0.85)' : '#B89968',
                  fontSize: card ? 14 : 9,
                }}>{card ? card.glyph : i+1}</div>
                <div style={{ fontSize: 8, color: '#B89968', textAlign: 'center', lineHeight: 1, letterSpacing: '0.04em' }}>
                  {p.length > 6 ? p.slice(0, 6) : p}
                </div>
              </div>
            );
          })}
        </div>

        {/* Fan */}
        <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>
          <CardFan deck={deck} drawn={drawn} onDraw={drawCard}/>
        </div>

        <div style={{ padding: '0 24px 12px', textAlign: 'center' }}>
          <div className="mono" style={{ fontSize: 9.5, color: 'rgba(184,153,104,0.6)', letterSpacing: '0.18em' }}>
            ← SCROLL — 30 cards available — SCROLL →
          </div>
        </div>
      </div>
    </Screen>
  );
}

function CardFan({ deck, drawn, onDraw }) {
  const drawnIdx = new Set(drawn.map(d => d.deckIdx));
  return (
    <div style={{
      position: 'absolute', left: 0, right: 0, bottom: 0, top: 0,
      overflowX: 'auto', overflowY: 'hidden', display: 'flex',
      alignItems: 'center', padding: '0 30px', justifyContent: 'flex-start',
      scrollbarWidth: 'none',
    }} className="fan-scroll">
      <div style={{
        display: 'flex', alignItems: 'center',
        height: '100%', position: 'relative',
        minWidth: deck.length * 28 + 200,
      }}>
        {deck.map((c, i) => {
          const isDrawn = drawnIdx.has(i);
          const total = deck.length;
          const mid = (total - 1) / 2;
          const t = (i - mid) / mid;
          const rot = t * 18;
          const lift = Math.abs(t) * 18;
          return (
            <button
              key={i}
              onClick={() => onDraw(i)}
              disabled={isDrawn}
              style={{
                background: 'none', border: 'none', padding: 0,
                cursor: isDrawn ? 'default' : 'pointer',
                marginLeft: i === 0 ? 0 : -68,
                transform: `rotate(${rot}deg) translateY(${isDrawn ? -200 : lift - 30}px)`,
                transformOrigin: 'bottom center',
                transition: 'transform 0.6s cubic-bezier(0.4, 0.1, 0.2, 1), opacity 0.4s',
                opacity: isDrawn ? 0 : 1,
                position: 'relative', zIndex: isDrawn ? 0 : i,
              }}
              onMouseEnter={e => {
                if (isDrawn) return;
                e.currentTarget.style.transform = `rotate(${rot}deg) translateY(${lift - 50}px)`;
              }}
              onMouseLeave={e => {
                if (isDrawn) return;
                e.currentTarget.style.transform = `rotate(${rot}deg) translateY(${lift - 30}px)`;
              }}
            >
              <ZenCardBack width={92}/>
            </button>
          );
        })}
      </div>
    </div>
  );
}

window.SpreadsScreen = SpreadsScreen;
window.SpreadDetailScreen = SpreadDetailScreen;
window.ShuffleScreen = ShuffleScreen;
window.DrawScreen = DrawScreen;
