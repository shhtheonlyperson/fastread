// Journal & Self screens

function JournalScreen({ goBack, readings, onOpen }) {
  const [filter, setFilter] = useState('all');
  const filtered = filter === 'all' ? readings : readings.filter(r => r.spreadId === filter);

  return (
    <Screen>
      <NavBar title="Journal" onBack={goBack} right={
        <button style={{ background: 'none', border: 'none', padding: 6, cursor: 'pointer' }}>{I.more()}</button>
      }/>
      <div className="scroll-y" style={{ flex: 1, padding: '4px 0 100px' }}>
        <div style={{ padding: '4px 24px 16px' }}>
          <div className="serif" style={{ fontSize: 36, fontStyle: 'italic', color: 'var(--c-ink)', letterSpacing: '-0.02em', lineHeight: 1.05 }}>
            What you've<br/>
            <span style={{ fontStyle: 'normal' }}>heard.</span>
          </div>
          <div className="serif" style={{ fontSize: 14, color: 'var(--c-ink-2)', marginTop: 10, lineHeight: 1.5 }}>
            {readings.length} {readings.length === 1 ? 'reading' : 'readings'} · all kept on this device.
          </div>
        </div>

        {/* filter chips */}
        <div style={{ padding: '0 24px 16px', display: 'flex', gap: 6, overflowX: 'auto', scrollbarWidth: 'none' }}>
          {[{id:'all',label:'All'}, ...window.OSHO_SPREADS.map(s => ({id:s.id, label: s.name}))].map(t => (
            <button key={t.id} onClick={() => setFilter(t.id)} style={{
              padding: '6px 12px', borderRadius: 99, fontSize: 12,
              border: '0.5px solid ' + (filter === t.id ? 'var(--c-clay)' : 'var(--c-line)'),
              background: filter === t.id ? 'var(--c-clay-wash)' : 'transparent',
              color: filter === t.id ? 'var(--c-clay-deep)' : 'var(--c-ink-2)',
              cursor: 'pointer', whiteSpace: 'nowrap', fontWeight: 500,
            }}>{t.label}</button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div style={{ padding: '60px 32px', textAlign: 'center' }}>
            <div style={{ fontSize: 36, color: 'var(--c-mute)' }} className="serif">禪</div>
            <div className="serif" style={{ fontSize: 17, color: 'var(--c-ink)', marginTop: 12, fontStyle: 'italic' }}>Nothing yet.</div>
            <div className="serif" style={{ fontSize: 13, color: 'var(--c-mute)', marginTop: 4 }}>Your saved readings will gather here.</div>
          </div>
        ) : (
          <div style={{ padding: '0 16px' }}>
            {filtered.map((r, i) => <JournalEntry key={r.id} reading={r} onClick={() => onOpen(r)} first={i === 0}/>)}
          </div>
        )}
      </div>
    </Screen>
  );
}

function JournalEntry({ reading, onClick, first }) {
  const date = new Date(reading.date);
  const cards = reading.cards.map(c => window.OSHO_CARDS.find(k => k.id === c.cardId)).filter(Boolean);
  return (
    <button onClick={onClick} style={{
      width: '100%', display: 'flex', gap: 14, padding: '16px 8px',
      background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left',
      borderTop: first ? 'none' : '0.5px solid var(--c-line)',
    }}>
      <div style={{ width: 44, textAlign: 'center', paddingTop: 4 }}>
        <div className="serif" style={{ fontSize: 24, color: 'var(--c-ink)', fontWeight: 500, lineHeight: 1 }}>
          {date.getDate()}
        </div>
        <div className="mono" style={{ fontSize: 9, letterSpacing: '0.16em', color: 'var(--c-mute)', marginTop: 4, textTransform: 'uppercase' }}>
          {date.toLocaleDateString('en-US',{month:'short'})}
        </div>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
          <div className="serif" style={{ fontSize: 16, color: 'var(--c-ink)', fontWeight: 500 }}>{reading.spreadName}</div>
          <div className="mono" style={{ fontSize: 9.5, letterSpacing: '0.14em', color: 'var(--c-clay)', fontWeight: 600 }}>{reading.cards.length}C</div>
        </div>
        {reading.question && (
          <div className="serif" style={{ fontSize: 13, color: 'var(--c-ink-2)', fontStyle: 'italic', marginTop: 2, lineHeight: 1.4 }}>
            "{reading.question}"
          </div>
        )}
        <div style={{ display: 'flex', gap: 4, marginTop: 8, flexWrap: 'wrap' }}>
          {cards.slice(0, 6).map((c, i) => (
            <div key={i} style={{
              fontSize: 10.5, padding: '2px 7px', borderRadius: 4,
              background: c.color + '14', color: c.color, fontWeight: 500,
              border: `0.5px solid ${c.color}30`,
            }} className="mono">{c.glyph} {c.name}</div>
          ))}
          {cards.length > 6 && (
            <div className="mono" style={{ fontSize: 10.5, color: 'var(--c-mute)', padding: '2px 4px' }}>+{cards.length - 6}</div>
          )}
        </div>
      </div>
    </button>
  );
}

// ─────────── Self / settings ───────────
function SelfScreen({ goBack, streak, totalReadings, onOpenInstructions }) {
  return (
    <Screen>
      <NavBar title="Self" onBack={goBack}/>
      <div className="scroll-y" style={{ flex: 1, padding: '4px 0 100px' }}>
        <div style={{ padding: '4px 24px 24px' }}>
          <div className="serif" style={{ fontSize: 36, fontStyle: 'italic', color: 'var(--c-ink)', letterSpacing: '-0.02em', lineHeight: 1.05 }}>
            Your<br/><span style={{ fontStyle: 'normal' }}>practice.</span>
          </div>
        </div>

        {/* Stats */}
        <div style={{ padding: '0 24px 12px', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
          <Stat n={streak} label="Day streak"/>
          <Stat n={totalReadings} label="Readings"/>
          <Stat n={'14'} label="Cards seen"/>
        </div>

        {/* Most-drawn cards */}
        <div style={{ padding: '24px 24px 0' }}>
          <div className="eyebrow" style={{ marginBottom: 12 }}>Cards that find you</div>
          <div style={{ display: 'flex', gap: 10, overflowX: 'auto', scrollbarWidth: 'none' }}>
            {window.OSHO_CARDS.slice(0, 6).map((c, i) => (
              <div key={c.id} style={{ flexShrink: 0, textAlign: 'center' }}>
                <ZenCardFace card={c} width={72}/>
                <div className="mono" style={{ fontSize: 9, letterSpacing: '0.14em', color: 'var(--c-mute)', marginTop: 6 }}>×{[5,4,3,2,2,1][i]}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Settings list */}
        <div style={{ padding: '32px 24px 0' }}>
          <div className="eyebrow" style={{ marginBottom: 10 }}>Settings</div>
          <div style={{ background: 'var(--c-paper)', borderRadius: 14, border: '0.5px solid var(--c-line)', overflow: 'hidden' }}>
            <SettingsRow label="Daily card reminder" value="9:41 AM" hasArrow/>
            <SettingsRow label="Language" value="English · 中文" hasArrow/>
            <SettingsRow label="Card animations" toggle defaultOn/>
            <SettingsRow label="Haptic feedback" toggle defaultOn/>
            <SettingsRow label="iCloud sync" toggle/>
          </div>
        </div>

        <div style={{ padding: '20px 24px 0' }}>
          <div className="eyebrow" style={{ marginBottom: 10 }}>Learn</div>
          <div style={{ background: 'var(--c-paper)', borderRadius: 14, border: '0.5px solid var(--c-line)', overflow: 'hidden' }}>
            <SettingsRow label="How to use the cards" hasArrow onClick={onOpenInstructions}/>
            <SettingsRow label="About Osho" hasArrow/>
            <SettingsRow label="Card index" hasArrow/>
          </div>
        </div>

        <div style={{ padding: '32px 24px 0', textAlign: 'center' }}>
          <div style={{ fontSize: 28, color: 'var(--c-clay)' }} className="serif">禪</div>
          <div className="serif" style={{ fontSize: 12, color: 'var(--c-mute)', fontStyle: 'italic', marginTop: 6 }}>v1.0 · made quietly</div>
        </div>
      </div>
    </Screen>
  );
}

function Stat({ n, label }) {
  return (
    <div style={{ background: 'var(--c-paper)', border: '0.5px solid var(--c-line)', borderRadius: 14, padding: '14px 12px', textAlign: 'center' }}>
      <div className="serif" style={{ fontSize: 28, color: 'var(--c-ink)', fontWeight: 500, lineHeight: 1 }}>{n}</div>
      <div className="mono" style={{ fontSize: 9, letterSpacing: '0.14em', color: 'var(--c-mute)', marginTop: 6, textTransform: 'uppercase' }}>{label}</div>
    </div>
  );
}

function SettingsRow({ label, value, hasArrow, toggle, defaultOn = false, onClick }) {
  const [on, setOn] = useState(defaultOn);
  return (
    <div onClick={onClick} style={{
      padding: '13px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      borderBottom: '0.5px solid var(--c-line)', cursor: onClick || hasArrow ? 'pointer' : 'default',
    }}>
      <div style={{ fontSize: 14, color: 'var(--c-ink)' }}>{label}</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        {value && <div style={{ fontSize: 13, color: 'var(--c-mute)' }}>{value}</div>}
        {hasArrow && I.arrow('#8B7F70')}
        {toggle && (
          <div onClick={e => { e.stopPropagation(); setOn(!on); }} style={{
            width: 42, height: 26, borderRadius: 99, padding: 2,
            background: on ? 'var(--c-clay)' : 'var(--c-line-2)',
            transition: 'background 0.2s', cursor: 'pointer',
          }}>
            <div style={{
              width: 22, height: 22, borderRadius: '50%', background: '#fff',
              transform: `translateX(${on ? 16 : 0}px)`, transition: 'transform 0.2s',
              boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
            }}/>
          </div>
        )}
      </div>
    </div>
  );
}

// ─────────── Instructions sheet (modal) ───────────
function InstructionsScreen({ goBack }) {
  const steps = [
    { n: '01', t: 'Settle', body: 'Find a quiet spot. Take three slow breaths. Let the day soften at the edges.' },
    { n: '02', t: 'Hold a question', body: 'A real question, asked sincerely, is already half the answer. Or hold no question — be open.' },
    { n: '03', t: 'Shuffle', body: 'Imagine the deck as a vessel. Pour your energy in. Stop when something inside says "now."' },
    { n: '04', t: 'Draw with the left hand', body: 'The left hand listens to the inner. Pick the cards that draw your eye, in the order they speak.' },
    { n: '05', t: 'Read slowly', body: 'Stay with the image before reading the words. The first response — the body\'s, not the mind\'s — is often the truest.' },
    { n: '06', t: 'Bow, and walk on', body: 'A reading is a mirror, not a verdict. Take what is useful. Let the rest go.' },
  ];
  return (
    <Screen>
      <NavBar title="Guide" onClose={goBack}/>
      <div className="scroll-y" style={{ flex: 1, padding: '0 0 80px' }}>
        <div style={{ padding: '8px 24px 24px' }}>
          <div className="mono" style={{ fontSize: 10, letterSpacing: '0.2em', color: 'var(--c-clay)', fontWeight: 600 }}>
            禪卡使用說明
          </div>
          <div className="serif" style={{ fontSize: 36, fontStyle: 'italic', color: 'var(--c-ink)', letterSpacing: '-0.02em', marginTop: 6, lineHeight: 1.05 }}>
            How to<br/><span style={{ fontStyle: 'normal' }}>use the cards.</span>
          </div>
          <div className="serif" style={{ fontSize: 15, color: 'var(--c-ink-2)', marginTop: 14, lineHeight: 1.5 }}>
            The tarot is not magic. It is a mirror — sometimes a sharp one. These cards do not predict your future; they reveal what you are already, quietly, beginning to know.
          </div>
        </div>

        <div style={{ padding: '4px 24px 0', display: 'flex', flexDirection: 'column', gap: 18 }}>
          {steps.map(s => (
            <div key={s.n} style={{ display: 'flex', gap: 14 }}>
              <div className="mono" style={{
                fontSize: 11, letterSpacing: '0.16em', color: 'var(--c-clay)',
                fontWeight: 700, paddingTop: 3, minWidth: 22,
              }}>{s.n}</div>
              <div style={{ flex: 1, paddingBottom: 2, borderBottom: '0.5px solid var(--c-line)', paddingBottom: 18 }}>
                <div className="serif" style={{ fontSize: 19, color: 'var(--c-ink)', fontStyle: 'italic' }}>{s.t}</div>
                <div className="serif" style={{ fontSize: 14, color: 'var(--c-ink-2)', marginTop: 6, lineHeight: 1.5 }}>{s.body}</div>
              </div>
            </div>
          ))}
        </div>

        <div style={{ padding: '24px 24px 0' }}>
          <div style={{
            background: 'var(--c-zen-night)', color: '#FAF7F2', borderRadius: 16,
            padding: '20px 18px', textAlign: 'center',
          }}>
            <div className="serif" style={{ fontSize: 28, color: '#B89968', fontStyle: 'italic' }}>"</div>
            <div className="serif" style={{ fontSize: 16, fontStyle: 'italic', lineHeight: 1.5, marginTop: -8 }}>
              Existence is the message. The cards only point.
            </div>
            <div className="mono" style={{ fontSize: 9.5, letterSpacing: '0.2em', color: '#B89968', marginTop: 12 }}>— OSHO</div>
          </div>
        </div>
      </div>
    </Screen>
  );
}

window.JournalScreen = JournalScreen;
window.SelfScreen = SelfScreen;
window.InstructionsScreen = InstructionsScreen;
