// Reading screen — reveal cards one by one, then show interpretations.

function ReadingScreen({ spread, question, drawn, goBack, goHome, onSave }) {
  const [revealed, setRevealed] = useState(0); // index up to which cards are face-up
  const [activeCard, setActiveCard] = useState(null);
  const [bookmarked, setBookmarked] = useState(false);

  // auto-reveal in sequence
  useEffect(() => {
    if (revealed >= drawn.length) return;
    const id = setTimeout(() => setRevealed(revealed + 1), revealed === 0 ? 350 : 700);
    return () => clearTimeout(id);
  }, [revealed, drawn.length]);

  const cards = drawn.map((d, i) => ({
    ...d,
    card: window.OSHO_CARDS.find(k => k.id === d.cardId),
    position: spread.positions[i],
    index: i,
  }));

  const allRevealed = revealed >= drawn.length;

  return (
    <Screen>
      <NavBar
        title={spread.name}
        onBack={goBack}
        right={
          <div style={{ display: 'flex', gap: 6 }}>
            <button onClick={() => setBookmarked(b => !b)} style={{
              background: 'none', border: 'none', padding: 6, cursor: 'pointer',
            }}>{I.bookmark('#1F1B16', bookmarked)}</button>
            <button style={{ background: 'none', border: 'none', padding: 6, cursor: 'pointer' }}>{I.share()}</button>
          </div>
        }
      />
      <div className="scroll-y" style={{ flex: 1, padding: '4px 0 100px' }}>
        {/* Header */}
        <div style={{ padding: '4px 24px 0' }}>
          <div className="mono" style={{ fontSize: 10, letterSpacing: '0.2em', color: 'var(--c-clay)', fontWeight: 600 }}>
            {new Date().toLocaleDateString('en-US',{month:'short', day:'numeric', year:'numeric'}).toUpperCase()} · {spread.zh}
          </div>
          <div className="serif" style={{ fontSize: 30, fontStyle: 'italic', color: 'var(--c-ink)', marginTop: 6, letterSpacing: '-0.01em', lineHeight: 1.05 }}>
            {question ? <>"{question}"</> : <>An open reading.</>}
          </div>
        </div>

        {/* Spread visualization */}
        <div style={{ padding: '24px 16px 16px' }}>
          <SpreadLayout spread={spread} cards={cards} revealedCount={revealed} onCardClick={setActiveCard}/>
        </div>

        {/* Synthesis */}
        {allRevealed && (
          <div style={{ animation: 'inkFade 0.7s ease', padding: '4px 24px 0' }}>
            <div style={{ height: 1, background: 'var(--c-line)', margin: '8px 0 22px' }}/>
            <div className="eyebrow" style={{ marginBottom: 10 }}>Synthesis</div>
            <div className="serif" style={{ fontSize: 18, color: 'var(--c-ink)', lineHeight: 1.45, fontStyle: 'italic' }}>
              {synthesizeReading(spread, cards)}
            </div>
          </div>
        )}

        {/* Cards in detail */}
        {allRevealed && (
          <div style={{ padding: '28px 24px 0', animation: 'inkFade 0.7s ease 0.2s both' }}>
            <div className="eyebrow" style={{ marginBottom: 14 }}>Each card, slowly</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {cards.map((c, i) => <CardReadingRow key={i} entry={c} onClick={() => setActiveCard(c)}/>)}
            </div>
          </div>
        )}

        {/* Save / new */}
        {allRevealed && (
          <div style={{ padding: '32px 24px 0', display: 'flex', gap: 10 }}>
            <button onClick={goHome} style={{
              flex: 1, padding: '14px', background: 'transparent', border: '0.5px solid var(--c-line-2)',
              borderRadius: 14, cursor: 'pointer', color: 'var(--c-ink)', fontFamily: 'var(--f-sans)',
              fontSize: 14.5, fontWeight: 500,
            }}>Done</button>
            <button onClick={onSave} style={{
              flex: 1, padding: '14px', background: 'var(--c-clay)', border: 'none', color: '#FAF7F2',
              borderRadius: 14, cursor: 'pointer', fontFamily: 'var(--f-sans)',
              fontSize: 14.5, fontWeight: 500,
              boxShadow: '0 8px 22px rgba(201,100,66,0.22)',
            }}>Save to journal</button>
          </div>
        )}
      </div>

      {activeCard && <CardSheet entry={activeCard} onClose={() => setActiveCard(null)}/>}
    </Screen>
  );
}

function synthesizeReading(spread, cards) {
  if (cards.length === 1) {
    return `Today asks for ${cards[0].card.keywords[0]}. Sit with ${cards[0].card.name.toLowerCase()} — let it speak first, then move.`;
  }
  if (spread.id === 'relationship') {
    return `You stand in ${cards[0].card.name.toLowerCase()}. They meet you from ${cards[1].card.name.toLowerCase()}. The space between is ${cards[2].card.name.toLowerCase()} — and love is asking for ${cards[3].card.name.toLowerCase()}.`;
  }
  if (spread.id === 'diamond') {
    return `Rooted in ${cards[0].card.name.toLowerCase()}, the past held ${cards[1].card.name.toLowerCase()} — the future hums with ${cards[2].card.name.toLowerCase()}. Inwardly: ${cards[3].card.name.toLowerCase()}. Outwardly: ${cards[4].card.name.toLowerCase()}.`;
  }
  return `A reading woven of ${cards.length} threads. The heart of it: ${cards.map(c => c.card.keywords[0]).join(' · ')}.`;
}

// ─────────── Layout that draws each spread shape ───────────
function SpreadLayout({ spread, cards, revealedCount, onCardClick }) {
  const w = 86;

  if (spread.id === 'meditation') {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', padding: '8px 0' }}>
        <div onClick={() => onCardClick(cards[0])} style={{ cursor: 'pointer' }}>
          <ZenCard card={cards[0].card} faceUp={revealedCount > 0} width={170}/>
          <PositionLabel label={cards[0].position}/>
        </div>
      </div>
    );
  }

  if (spread.id === 'relationship') {
    // 2 top, 1 mid, 1 bottom — vertical diamond-ish
    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16 }}>
        <div style={{ display: 'flex', gap: 22 }}>
          <SlotCard entry={cards[0]} faceUp={revealedCount > 0} onClick={onCardClick} width={w}/>
          <SlotCard entry={cards[1]} faceUp={revealedCount > 1} onClick={onCardClick} width={w}/>
        </div>
        <SlotCard entry={cards[2]} faceUp={revealedCount > 2} onClick={onCardClick} width={w}/>
        <SlotCard entry={cards[3]} faceUp={revealedCount > 3} onClick={onCardClick} width={w}/>
      </div>
    );
  }

  if (spread.id === 'diamond') {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14 }}>
        <SlotCard entry={cards[0]} faceUp={revealedCount > 0} onClick={onCardClick} width={w}/>
        <div style={{ display: 'flex', gap: 18, alignItems: 'center' }}>
          <SlotCard entry={cards[1]} faceUp={revealedCount > 1} onClick={onCardClick} width={w}/>
          <SlotCard entry={cards[3]} faceUp={revealedCount > 3} onClick={onCardClick} width={w}/>
          <SlotCard entry={cards[2]} faceUp={revealedCount > 2} onClick={onCardClick} width={w}/>
        </div>
        <SlotCard entry={cards[4]} faceUp={revealedCount > 4} onClick={onCardClick} width={w}/>
      </div>
    );
  }

  if (spread.id === 'key') {
    // 8 cards as key-tooth pattern
    return (
      <div style={{ overflowX: 'auto', scrollbarWidth: 'none' }}>
        <div style={{ display: 'flex', gap: 8, padding: '0 16px', width: 'max-content', alignItems: 'flex-end' }}>
          {cards.map((c, i) => (
            <div key={i} style={{ marginTop: i % 2 === 0 ? 0 : 24 }}>
              <SlotCard entry={c} faceUp={revealedCount > i} onClick={onCardClick} width={70}/>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (spread.id === 'mirror') {
    // 12 cards in a circle
    const radius = 130;
    const cardW = 60;
    return (
      <div style={{ position: 'relative', width: '100%', height: 360, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        {cards.map((c, i) => {
          const a = (i / 12) * Math.PI * 2 - Math.PI / 2;
          return (
            <div key={i} style={{
              position: 'absolute', left: '50%', top: '50%',
              transform: `translate(${Math.cos(a) * radius - cardW/2}px, ${Math.sin(a) * radius - cardW*0.78}px) rotate(${(a*180/Math.PI + 90)}deg)`,
            }}>
              <div onClick={() => onCardClick(c)} style={{ cursor: 'pointer' }}>
                <ZenCard card={c.card} faceUp={revealedCount > i} width={cardW}/>
              </div>
            </div>
          );
        })}
        <div style={{
          width: 110, height: 110, borderRadius: '50%', background: 'var(--c-paper)',
          border: '0.5px solid var(--c-line)', display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center',
        }}>
          <div className="serif" style={{ fontSize: 28, fontStyle: 'italic', color: 'var(--c-clay)' }}>禪</div>
          <div className="mono" style={{ fontSize: 8.5, letterSpacing: '0.18em', color: 'var(--c-mute)', marginTop: 4 }}>MIRROR</div>
        </div>
      </div>
    );
  }

  return null;
}

function SlotCard({ entry, faceUp, onClick, width }) {
  return (
    <div onClick={() => onClick(entry)} style={{ cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      <ZenCard card={entry.card} faceUp={faceUp} width={width}/>
      <PositionLabel label={entry.position}/>
    </div>
  );
}

function PositionLabel({ label }) {
  return (
    <div className="mono" style={{
      marginTop: 8, fontSize: 9.5, letterSpacing: '0.16em',
      color: 'var(--c-mute)', textTransform: 'uppercase', textAlign: 'center',
    }}>{label}</div>
  );
}

function CardReadingRow({ entry, onClick }) {
  const c = entry.card;
  return (
    <button onClick={onClick} style={{
      background: 'var(--c-paper)', border: '0.5px solid var(--c-line)',
      borderRadius: 14, padding: 14, display: 'flex', gap: 14, alignItems: 'flex-start',
      cursor: 'pointer', textAlign: 'left',
    }}>
      <ZenCardFace card={c} width={64}/>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div className="mono" style={{ fontSize: 9.5, letterSpacing: '0.18em', color: 'var(--c-clay)', fontWeight: 600 }}>
          {entry.position.toUpperCase()}
        </div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 2 }}>
          <div className="serif" style={{ fontSize: 17, color: 'var(--c-ink)', fontWeight: 500 }}>{c.name}</div>
          <div className="serif" style={{ fontSize: 12, color: 'var(--c-mute)', fontStyle: 'italic' }}>{c.zh}</div>
        </div>
        <div style={{
          marginTop: 4, fontSize: 12.5, color: 'var(--c-ink-2)', lineHeight: 1.45,
          display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden',
        }}>{c.body}</div>
      </div>
    </button>
  );
}

// ─────────── Card detail bottom sheet ───────────
function CardSheet({ entry, onClose }) {
  const c = entry.card;
  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 50,
      animation: 'inkFade 0.3s ease',
    }}>
      <div onClick={onClose} style={{
        position: 'absolute', inset: 0, background: 'rgba(20,17,13,0.5)',
        backdropFilter: 'blur(4px)', WebkitBackdropFilter: 'blur(4px)',
      }}/>
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0,
        background: 'var(--c-canvas)', borderRadius: '20px 20px 0 0',
        padding: '8px 0 24px', maxHeight: '88%', display: 'flex', flexDirection: 'column',
        boxShadow: '0 -10px 30px rgba(0,0,0,0.18)',
        animation: 'inkFade 0.35s cubic-bezier(0.4, 0.1, 0.2, 1)',
      }}>
        <div style={{ width: 36, height: 4, background: 'var(--c-line-2)', borderRadius: 99, margin: '6px auto 0' }}/>
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 18px 0' }}>
          <div className="mono" style={{ fontSize: 9.5, letterSpacing: '0.18em', color: 'var(--c-clay)', fontWeight: 600 }}>
            {entry.position.toUpperCase()}
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}>{I.close()}</button>
        </div>
        <div className="scroll-y" style={{ flex: 1, padding: '8px 24px 0' }}>
          <div style={{ display: 'flex', justifyContent: 'center', padding: '10px 0 18px' }}>
            <ZenCardFace card={c} width={170}/>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div className="mono" style={{ fontSize: 10, letterSpacing: '0.2em', color: 'var(--c-mute)' }}>
              NO. {String(c.num).padStart(2,'0')} · {c.suit.toUpperCase()}
            </div>
            <div className="serif" style={{ fontSize: 32, fontStyle: 'italic', color: 'var(--c-ink)', marginTop: 6, letterSpacing: '-0.01em' }}>{c.name}</div>
            <div className="serif" style={{ fontSize: 16, color: 'var(--c-mute)', fontStyle: 'italic', marginTop: 2 }}>{c.zh}</div>
          </div>
          <div style={{ display: 'flex', gap: 6, justifyContent: 'center', marginTop: 14, flexWrap: 'wrap' }}>
            {c.keywords.map(k => (
              <div key={k} className="mono" style={{
                fontSize: 10, letterSpacing: '0.12em', color: 'var(--c-clay-deep)',
                background: 'var(--c-clay-wash)', padding: '4px 10px', borderRadius: 99,
                textTransform: 'uppercase', fontWeight: 600,
              }}>{k}</div>
            ))}
          </div>
          <div style={{ height: 1, background: 'var(--c-line)', margin: '20px 0 18px' }}/>
          <div className="serif" style={{ fontSize: 17, color: 'var(--c-ink)', lineHeight: 1.55, fontStyle: 'italic' }}>
            {c.body}
          </div>
          <div style={{ height: 1, background: 'var(--c-line)', margin: '22px 0 16px' }}/>
          <div className="eyebrow" style={{ marginBottom: 8 }}>For reflection</div>
          <div className="serif" style={{ fontSize: 14.5, color: 'var(--c-ink-2)', lineHeight: 1.55 }}>
            {reflectionFor(c)}
          </div>
          <div style={{ height: 32 }}/>
        </div>
      </div>
    </div>
  );
}

function reflectionFor(c) {
  const Q = {
    fool: 'Where in your life is innocence asking to begin again?',
    existence: 'What if you needed to do nothing more today?',
    courage: 'What small, true act would scare and free you both?',
    aloneness: 'Can you stay with yourself for ten minutes without reaching for anything?',
    breakthrough: 'What is breaking? And what wants to be born?',
    silence: 'What would you hear if you stopped explaining?',
    transformation: 'What are you ready to let die — kindly?',
    completion: 'What is asking to be honored as finished?',
  };
  return Q[c.id] || `Where in your life is ${c.keywords[0]} asking to be felt?`;
}

window.ReadingScreen = ReadingScreen;
window.CardSheet = CardSheet;
