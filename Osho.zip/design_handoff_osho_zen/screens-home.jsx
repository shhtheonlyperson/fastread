// Osho Zen — main app screens
const { useState, useEffect, useMemo, useRef } = React;

// ──────────────────────────── Icons ────────────────────────────
const I = {
  back: (c='#1F1B16') => <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M15 5l-7 7 7 7" stroke={c} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  close: (c='#1F1B16') => <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke={c} strokeWidth="1.7" strokeLinecap="round"/></svg>,
  more: (c='#1F1B16') => <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><circle cx="5" cy="12" r="1.6" fill={c}/><circle cx="12" cy="12" r="1.6" fill={c}/><circle cx="19" cy="12" r="1.6" fill={c}/></svg>,
  share: (c='#1F1B16') => <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 3v12M12 3l-4 4M12 3l4 4M5 14v5a2 2 0 002 2h10a2 2 0 002-2v-5" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  bookmark: (c='#1F1B16', f=false) => <svg width="18" height="18" viewBox="0 0 24 24" fill={f?c:'none'}><path d="M6 4h12v17l-6-4-6 4V4z" stroke={c} strokeWidth="1.6" strokeLinejoin="round"/></svg>,
  arrow: (c='#1F1B16') => <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M5 12h14M13 6l6 6-6 6" stroke={c} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  home: (c='#1F1B16',f=false) => <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M3 11l9-7 9 7v9a1 1 0 01-1 1h-5v-6h-6v6H4a1 1 0 01-1-1v-9z" stroke={c} fill={f?c:'none'} strokeWidth="1.6" strokeLinejoin="round"/></svg>,
  card: (c='#1F1B16',f=false) => <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><rect x="4" y="3" width="11" height="16" rx="2" stroke={c} fill={f?c:'none'} strokeWidth="1.6"/><rect x="9" y="6" width="11" height="16" rx="2" stroke={c} fill="none" strokeWidth="1.6"/></svg>,
  journal: (c='#1F1B16',f=false) => <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M5 4h11l3 3v13a1 1 0 01-1 1H5a1 1 0 01-1-1V5a1 1 0 011-1z" stroke={c} fill={f?c:'none'} strokeWidth="1.6"/><path d="M8 9h8M8 13h8M8 17h5" stroke={f?'#FAF7F2':c} strokeWidth="1.4" strokeLinecap="round"/></svg>,
  user: (c='#1F1B16',f=false) => <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="4" stroke={c} fill={f?c:'none'} strokeWidth="1.6"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6" stroke={c} fill={f?c:'none'} strokeWidth="1.6" strokeLinecap="round"/></svg>,
  sparkle: (c='#C96442') => <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M12 3l1.5 5.5L19 10l-5.5 1.5L12 17l-1.5-5.5L5 10l5.5-1.5L12 3z" fill={c}/></svg>,
  shuffle: (c='#FAF7F2') => <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M3 7h4l4 5-4 5H3M14 7h3l4 5-4 5h-3M21 7l-2-2M21 7l-2 2M21 17l-2-2M21 17l-2 2" stroke={c} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  globe: (c='#1F1B16') => <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" stroke={c} strokeWidth="1.5"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18" stroke={c} strokeWidth="1.5"/></svg>,
};

// ──────────────────────────── Layout primitives ────────────────────────────
function Screen({ children, bg = 'var(--c-canvas)' }) {
  return (
    <div style={{
      width: '100%', height: '100%', background: bg,
      display: 'flex', flexDirection: 'column', position: 'relative',
      overflow: 'hidden',
    }}>{children}</div>
  );
}

function NavBar({ title, onBack, onClose, right, transparent = false, dark = false }) {
  const c = dark ? '#FAF7F2' : '#1F1B16';
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '6px 16px 10px', minHeight: 44,
      background: transparent ? 'transparent' : 'var(--c-canvas)',
    }}>
      <div style={{ width: 60, display: 'flex', alignItems: 'center' }}>
        {onBack && <button onClick={onBack} style={{
          background: 'none', border: 'none', padding: 0, cursor: 'pointer',
          display: 'flex', alignItems: 'center', gap: 2, color: c,
        }}>{I.back(c)}</button>}
        {onClose && <button onClick={onClose} style={{
          background: 'none', border: 'none', padding: 0, cursor: 'pointer',
        }}>{I.close(c)}</button>}
      </div>
      <div className="serif" style={{
        fontSize: 17, fontWeight: 500, color: c, letterSpacing: '-0.01em',
      }}>{title}</div>
      <div style={{ width: 60, display: 'flex', justifyContent: 'flex-end' }}>{right}</div>
    </div>
  );
}

function TabBar({ tab, setTab }) {
  const tabs = [
    { id: 'home', label: 'Today', icon: I.home },
    { id: 'spreads', label: 'Spreads', icon: I.card },
    { id: 'journal', label: 'Journal', icon: I.journal },
    { id: 'self', label: 'Self', icon: I.user },
  ];
  return (
    <div style={{
      borderTop: '0.5px solid var(--c-line)',
      background: 'rgba(245,241,235,0.92)',
      backdropFilter: 'blur(20px)',
      WebkitBackdropFilter: 'blur(20px)',
      padding: '6px 8px 22px',
      display: 'flex', justifyContent: 'space-around',
    }}>
      {tabs.map(t => {
        const active = t.id === tab;
        const c = active ? 'var(--c-clay)' : 'var(--c-mute)';
        return (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            background: 'none', border: 'none', padding: '6px 12px',
            display: 'flex', flexDirection: 'column', alignItems: 'center',
            gap: 3, cursor: 'pointer', color: c,
          }}>
            {t.icon(active ? '#C96442' : '#8B7F70', active)}
            <div style={{ fontSize: 10.5, fontWeight: 500, letterSpacing: '0.02em' }}>{t.label}</div>
          </button>
        );
      })}
    </div>
  );
}

// ──────────────────────────── Home / Today ────────────────────────────
function HomeScreen({ goSpread, goAllSpreads, goCardOfDay, goJournal, recentReadings, todayCard }) {
  const today = new Date();
  const dateStr = today.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
  return (
    <Screen>
      <div className="scroll-y" style={{ flex: 1, padding: '4px 0 80px' }}>
        {/* Top eyebrow */}
        <div style={{ padding: '8px 24px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div className="eyebrow">{dateStr}</div>
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            {I.globe('#8B7F70')}
            <span className="mono" style={{ fontSize: 10, color: 'var(--c-mute)', letterSpacing: '0.12em' }}>EN · 中</span>
          </div>
        </div>

        {/* Editorial title */}
        <div style={{ padding: '18px 24px 6px' }}>
          <div className="serif" style={{ fontSize: 40, lineHeight: 1.02, color: 'var(--c-ink)', fontStyle: 'italic', letterSpacing: '-0.02em' }}>
            Osho<br/>
            <span style={{ fontStyle: 'normal', fontWeight: 300 }}>Zen Cards.</span>
          </div>
          <div style={{ marginTop: 10, fontFamily: 'var(--f-serif)', fontSize: 15.5, color: 'var(--c-ink-2)', lineHeight: 1.5, maxWidth: 280 }}>
            A mirror, not an oracle. Shuffle, breathe, and let what you already know rise to meet you.
          </div>
        </div>

        {/* Card of the day */}
        <div style={{ padding: '24px 24px 0' }}>
          <div className="eyebrow" style={{ marginBottom: 12 }}>Card of the day</div>
          <button onClick={goCardOfDay} style={{
            width: '100%', display: 'flex', gap: 16, alignItems: 'center',
            padding: 14, background: 'var(--c-paper)', borderRadius: 16,
            border: '0.5px solid var(--c-line)',
            boxShadow: '0 1px 0 rgba(255,255,255,0.6) inset, 0 8px 24px rgba(31,27,22,0.04)',
            cursor: 'pointer', textAlign: 'left',
          }}>
            <ZenCard card={todayCard} faceUp={true} width={86}/>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="mono" style={{ fontSize: 10, color: 'var(--c-mute)', letterSpacing: '0.14em' }}>NO. {String(todayCard.num).padStart(2,'0')} · {todayCard.suit.toUpperCase()}</div>
              <div className="serif" style={{ fontSize: 22, marginTop: 4, color: 'var(--c-ink)', fontWeight: 500 }}>{todayCard.name}</div>
              <div className="serif" style={{ fontSize: 13, fontStyle: 'italic', color: 'var(--c-mute)', marginTop: 1 }}>{todayCard.zh}</div>
              <div style={{
                marginTop: 8, fontSize: 12.5, color: 'var(--c-ink-2)', lineHeight: 1.4,
                display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden',
              }}>{todayCard.body}</div>
            </div>
          </button>
        </div>

        {/* Spreads grid */}
        <div style={{ padding: '32px 24px 0' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 }}>
            <div className="eyebrow">Choose a spread</div>
            <button onClick={goAllSpreads} style={{
              background: 'none', border: 'none', padding: 0, cursor: 'pointer',
              fontSize: 12, color: 'var(--c-clay)', fontWeight: 500,
            }}>All five →</button>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {window.OSHO_SPREADS.slice(0, 4).map((s, i) => <SpreadTile key={s.id} spread={s} onClick={() => goSpread(s.id)} variant={i}/>)}
          </div>
        </div>

        {/* Recent readings */}
        {recentReadings.length > 0 && (
          <div style={{ padding: '32px 24px 0' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 }}>
              <div className="eyebrow">Recent readings</div>
              <button onClick={goJournal} style={{
                background: 'none', border: 'none', padding: 0, cursor: 'pointer',
                fontSize: 12, color: 'var(--c-clay)', fontWeight: 500,
              }}>Journal →</button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 1, background: 'var(--c-line)', borderRadius: 14, overflow: 'hidden' }}>
              {recentReadings.slice(0,3).map(r => <ReadingRow key={r.id} reading={r}/>)}
            </div>
          </div>
        )}

        {/* Quote */}
        <div style={{ padding: '40px 32px 24px', textAlign: 'center' }}>
          <div className="serif" style={{
            fontSize: 17, fontStyle: 'italic', color: 'var(--c-ink-2)',
            lineHeight: 1.4, fontWeight: 400,
          }}>"The tarot is a tool to expose what you already know — to bring it to a position where you can see it."</div>
          <div style={{ marginTop: 10 }} className="mono">
            <span style={{ fontSize: 10, color: 'var(--c-mute)', letterSpacing: '0.18em' }}>— OSHO</span>
          </div>
        </div>
      </div>
    </Screen>
  );
}

function SpreadTile({ spread, onClick, variant = 0 }) {
  // Visual: tiny diagram of the spread layout
  return (
    <button onClick={onClick} style={{
      background: 'var(--c-paper)', border: '0.5px solid var(--c-line)',
      borderRadius: 14, padding: 14, cursor: 'pointer', textAlign: 'left',
      display: 'flex', flexDirection: 'column', gap: 12,
      boxShadow: '0 1px 0 rgba(255,255,255,0.6) inset',
      aspectRatio: '1 / 1.05',
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div className="mono" style={{ fontSize: 9.5, letterSpacing: '0.16em', color: 'var(--c-clay)', fontWeight: 600 }}>
          {String(spread.count).padStart(2,'0')} CARDS
        </div>
        {I.arrow('#8B7F70')}
      </div>
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <SpreadDiagram spread={spread}/>
      </div>
      <div>
        <div className="serif" style={{ fontSize: 18, color: 'var(--c-ink)', fontWeight: 500, lineHeight: 1.05 }}>
          {spread.name}
        </div>
        <div className="serif" style={{ fontSize: 11.5, color: 'var(--c-mute)', fontStyle: 'italic', marginTop: 2 }}>
          {spread.zh}
        </div>
      </div>
    </button>
  );
}

function SpreadDiagram({ spread, size = 80, color = 'var(--c-clay)', dim = 'var(--c-line-2)' }) {
  // Mini diagram per spread
  const dot = (x, y, big = false) => (
    <rect x={x - (big?4:3)} y={y - (big?5:4)} width={big?8:6} height={big?10:8} rx="1" fill={color}/>
  );
  const sz = size;
  return (
    <svg width={sz} height={sz} viewBox="0 0 80 80" style={{ overflow: 'visible' }}>
      {spread.id === 'meditation' && <g><rect x="36" y="35" width="8" height="10" rx="1" fill={color}/></g>}
      {spread.id === 'relationship' && <g>
        <rect x="17" y="26" width="6" height="8" rx="1" fill={color}/>
        <rect x="57" y="26" width="6" height="8" rx="1" fill={color}/>
        <rect x="37" y="46" width="6" height="8" rx="1" fill={color}/>
        <rect x="37" y="66" width="6" height="8" rx="1" fill={color}/>
        <line x1="20" y1="30" x2="60" y2="30" stroke={dim} strokeWidth="0.5" strokeDasharray="2 2"/>
      </g>}
      {spread.id === 'diamond' && <g>
        <rect x="37" y="8" width="6" height="8" rx="1" fill={color}/>
        <rect x="11" y="36" width="6" height="8" rx="1" fill={color}/>
        <rect x="36" y="35" width="8" height="10" rx="1" fill={color}/>
        <rect x="63" y="36" width="6" height="8" rx="1" fill={color}/>
        <rect x="37" y="64" width="6" height="8" rx="1" fill={color}/>
      </g>}
      {spread.id === 'key' && <g>
        {[0,1,2,3,4,5,6,7].map(i => (
          <rect key={i} x={5 + i*8.5} y={36 + (i%2===0?-8:8)} width="6" height="8" rx="1" fill={color}/>
        ))}
      </g>}
      {spread.id === 'mirror' && <g>{Array.from({length:12}).map((_,i) => {
          const a = (i / 12) * Math.PI * 2 - Math.PI/2;
          return <rect key={i} x={40 + Math.cos(a)*28 - 2} y={40 + Math.sin(a)*28 - 3} width="4" height="6" rx="0.6" fill={color}/>;
        })}</g>}
    </svg>
  );
}

function ReadingRow({ reading, onClick }) {
  const date = new Date(reading.date);
  const cards = reading.cards.map(c => window.OSHO_CARDS.find(k => k.id === c.cardId)).filter(Boolean);
  return (
    <button onClick={onClick} style={{
      background: 'var(--c-paper)', border: 'none', padding: '14px 14px',
      display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer', textAlign: 'left',
      width: '100%',
    }}>
      <div style={{ display: 'flex', gap: -6, position: 'relative', width: 38, height: 56 }}>
        {cards.slice(0,3).map((c,i) => (
          <div key={i} style={{ position: 'absolute', left: i*8, top: i*2, transform: `rotate(${(i-1)*4}deg)` }}>
            <ZenCardFace card={c} width={36}/>
          </div>
        ))}
      </div>
      <div style={{ flex: 1, marginLeft: 16 }}>
        <div className="serif" style={{ fontSize: 15, color: 'var(--c-ink)' }}>{reading.spreadName}</div>
        <div className="mono" style={{ fontSize: 10.5, color: 'var(--c-mute)', letterSpacing: '0.1em', marginTop: 2 }}>
          {date.toLocaleDateString('en-US',{month:'short', day:'numeric'}).toUpperCase()} · {reading.cards.length} CARDS
        </div>
      </div>
      {I.arrow('#8B7F70')}
    </button>
  );
}

window.HomeScreen = HomeScreen;
window.NavBar = NavBar;
window.TabBar = TabBar;
window.Screen = Screen;
window.I = I;
window.SpreadDiagram = SpreadDiagram;
window.ReadingRow = ReadingRow;
window.SpreadTile = SpreadTile;
