# Handoff: Osho Zen Cards — iOS App

## Overview
A meditative iOS app that recreates the functionality of osho.theonlyperson.com — a digital Osho Zen Card divination tool. Users choose a spread (1, 4, 5, 8, or 12 cards), optionally hold a question, shuffle and draw cards, then read the result with a synthesis and per-card detail. Saved readings live in a journal.

## About the Design Files
The files in this bundle are **design references created in HTML/JSX** — interactive prototypes showing the intended look, motion, and behavior. They are **not production code to ship**. The task is to recreate these designs in the target codebase's environment (recommended: **SwiftUI** for native iOS, since this is an iOS app). If a web/React Native target is preferred instead, the JSX components map cleanly.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, animations, and copy are all decided. Recreate pixel-faithfully in the target environment.

## Recommended Target
**SwiftUI on iOS 17+.** The design uses iOS 26-style materials, system fonts (SF Pro), and native nav patterns. A `UIHostingController` is overkill — go SwiftUI top-to-bottom.

---

## Design Tokens

### Colors (Claude editorial — warm cream + terracotta)
| Token            | Hex       | Usage                                     |
|------------------|-----------|-------------------------------------------|
| `c-canvas`       | `#F5F1EB` | App background (warm limestone)           |
| `c-paper`        | `#FAF7F2` | Card surface                              |
| `c-paper-2`      | `#EFE9DF` | Inset / muted surface                     |
| `c-ink`          | `#1F1B16` | Primary text (deep ink)                   |
| `c-ink-2`        | `#3A332B` | Body text                                 |
| `c-mute`         | `#8B7F70` | Captions, metadata                        |
| `c-line`         | `#E3DCD0` | Hairline borders                          |
| `c-line-2`       | `#D6CDBE` | Stronger borders                          |
| `c-clay`         | `#C96442` | **Primary terracotta accent**             |
| `c-clay-deep`    | `#A24C30` | Pressed / active accent                   |
| `c-clay-soft`    | `#E8D5C4` | Tinted bg                                 |
| `c-clay-wash`    | `#F2E4D7` | Very soft wash for chips                  |
| `c-zen-night`    | `#14110D` | Dark canvas (shuffle/draw screens)        |
| `c-zen-gold`     | `#B89968` | Sigil/border on dark                      |
| `c-zen-violet`   | `#5B4B7A` | Mystic accent                             |

### Typography
- **Display / editorial:** `Source Serif 4` (italic 32–40 px for hero titles)
- **Body / UI:** `Inter` (system fallback to SF Pro Text)
- **Labels / eyebrows:** `JetBrains Mono` (10–11 px, uppercase, letter-spacing 0.16–0.22 em)
- All sizes in pt for SwiftUI; scale as listed in HTML.

### Radii
| Token | Value |
|-------|-------|
| sm    | 6 px  |
| md    | 12 px |
| lg    | 18 px |
| xl    | 24 px |

### Spacing scale (4 px base)
4, 8, 12, 16, 20, 24, 32, 48

---

## Screens

### 1. Today (Home tab)
- Eyebrow: live date + EN/中 indicator
- Hero serif title: "Osho / Zen Cards." (italic + roman)
- Card-of-the-day card: small face-up card + name/zh/2-line excerpt
- 2×2 grid of spread tiles, "All five →" link
- Recent readings list (3 most recent)
- Footer Osho quote

### 2. Spreads tab
- Editorial title "Five ways / to listen."
- Vertical list of all 5 spreads, each with mini-diagram, name, zh, tagline, card count
- Dark instructions card at bottom

### 3. Spread detail
- Circular badge containing the spread diagram
- Centered eyebrow ("05 CARDS · 鑽石菱形") + italic title + description
- Positions grid (2 or 3 cols based on count)
- Optional textarea for question (serif font, paper bg)
- Primary button "Begin shuffling" (terracotta)

### 4. Shuffle (dark canvas)
- Eyebrow "SHUFFLING · 洗牌" → "READY · 準備就緒"
- 5 stacked card-backs animated with staggered shuf keyframe
- Progress bar (gold) auto-fills over ~3 s
- "SKIP SHUFFLE" link, then "Cut the deck →" terracotta button

### 5. Draw (dark canvas)
- Slot tracker at top showing all positions (filled = drawn glyph, empty = number)
- Header changes: "Choose Root" with current position name highlighted clay
- Horizontally-scrolling fan of 30 face-down cards
- Tap to draw → card animates up and fades out, slot fills
- Auto-advance to Reading when count reached

### 6. Reading (light canvas)
- Eyebrow date + spread zh
- Italic question or "An open reading."
- Spread-shaped layout (custom per spread):
  - **Meditation:** single 170-px card centered
  - **Relationship:** 2 top, 1 mid, 1 bottom
  - **Diamond:** top–center row of 3–bottom
  - **Key:** zigzag horizontal scroll
  - **Mirror:** 12 cards in a circle, each rotated to face out, central 禪 disc
- Sequential flip-reveal (350 ms first, 700 ms each next)
- After full reveal: italic synthesis paragraph
- Per-card rows: face thumbnail, position eyebrow, name + zh, 3-line excerpt
- Done / Save to journal buttons

### 7. Card detail bottom sheet
- Modal sheet with grabber, position eyebrow, close
- Large face card centered, no/suit eyebrow, name + zh
- Keyword chips (clay-wash bg, clay-deep text)
- Italic body interpretation
- "For reflection" prompt (custom per major arcana, fallback for others)

### 8. Journal tab
- Hero title "What you've / heard."
- Filter chips (All + each spread)
- Date-anchored entries: day number + month abbrev, name, italic question, card chips colored per card

### 9. Self tab
- Hero "Your / practice."
- 3 stat cards: streak, readings, cards seen
- Horizontal scroll of most-drawn card faces
- Settings groups (paper bg, hairline-divided rows): reminder time, language, animations, haptics, iCloud, learn links

### 10. Instructions
- 6 numbered steps in serif, mono numbers
- Dark zen quote card at bottom

---

## Interactions

- **Card flip:** 700 ms `cubic-bezier(0.4, 0.1, 0.2, 1)` on Y-axis, two-sided with `backface-visibility: hidden`
- **Fan hover lift:** -20 px translate on enter
- **Shuffle stack:** 5 cards each `shuf` keyframe with 0.08 s stagger
- **Glow pulse:** 3 s ease-in-out radial behind shuffle stack
- **Bottom sheet:** slide + fade in 350 ms
- **Tab change:** instant (no animation)
- **Auto-reveal:** first card 350 ms after mount, subsequent 700 ms each
- **Toggle:** 22-px circle slides 16 px in 200 ms

---

## State Management

- `stack: Screen[]` — navigation stack with kinds: tabs, spread-detail, shuffle, draw, reading, reading-view, card-of-day, instructions
- `readings: Reading[]` — persisted to local storage / `UserDefaults` / Core Data; seeded with 3 demo entries on first run
- Reading shape: `{ id, spreadId, spreadName, question, cards: [{cardId, position}], date }`
- `tweaks: { accentHue, cardBack, showHaptic }` — for prototype only; production app would expose subset as Settings

---

## Card Data
30 cards total — 22 Major Arcana (`fool` → `completion`) plus 8 sample suit cards (fire/water/clouds/rainbow). Each card has:
- `id, suit, num, name, zh, color (hex), glyph (unicode), keywords[], body (interpretation)`

All copy is original — written for this app, not lifted from any specific Osho deck publication. Replace if licensing the official deck.

## Spreads
- `meditation` — 1 card · 靜心 · "Now"
- `relationship` — 4 cards · 關係 · You / Them / Between / The Invitation
- `diamond` — 5 cards · 鑽石菱形 · Root / Past / Future / Inner / Outer
- `key` — 8 cards · 鑰匙 · The Door / What Holds / What Frees / Body / Heart / Mind / Path / Threshold
- `mirror` — 12 cards · 鏡子 · Jan–Dec

---

## Assets
None external — all imagery is generated:
- Card backs: SVG concentric circles + "zen" italic lockup in gold
- Card faces: gradient color field + unicode glyph + serif name
- Icons: inline SVG (back, close, more, share, bookmark, arrow, tab icons)
- No raster images required

---

## Files in this bundle
- `Osho Zen.html` — entry point
- `tokens.css` — design tokens
- `cards.js` — card + spread data
- `card-component.jsx` — `<ZenCard>`, `<ZenCardFace>`, `<ZenCardBack>`
- `screens-home.jsx` — Home + tab bar + spread tiles
- `screens-flow.jsx` — Spreads list, detail, shuffle, draw
- `screens-reading.jsx` — Reading layout + card sheet
- `screens-misc.jsx` — Journal, Self, Instructions
- `app.jsx` — Navigation + state + tweaks panel wiring
- `ios-frame.jsx`, `tweaks-panel.jsx` — prototype scaffolding (do not port)

## Notes for the developer
- The HTML iOS frame is for preview only — drop it; SwiftUI gives you status bar + nav for free.
- Persist the reading list with `@AppStorage` (JSON-encoded) for v1; migrate to SwiftData if/when shape grows.
- Haptics: `UIImpactFeedbackGenerator(.soft)` on card flip and draw; `.success` notification on reading complete.
- Use `matchedGeometryEffect` for the card moving from fan → reading slot.
- The Mirror spread (12 cards in a circle) needs a `ZStack` with rotation per card — keep the central 禪 disc as a separate layer.
- Source Serif 4 is on Google Fonts; bundle the static .ttfs in the iOS app.
