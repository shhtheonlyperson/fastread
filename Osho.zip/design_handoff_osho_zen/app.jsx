// Main app — wires all screens together inside the iOS frame.

const STORAGE_KEY = 'osho-zen-readings';

// Seed readings for first-run delight
function seedReadings() {
  const cards = window.OSHO_CARDS;
  const find = id => cards.find(c => c.id === id);
  const today = Date.now();
  const day = 86400000;
  return [
    {
      id: 'r1', spreadId: 'meditation', spreadName: 'Meditation',
      date: today - 1*day, question: '',
      cards: [{ cardId: 'silence', position: 'Now' }],
    },
    {
      id: 'r2', spreadId: 'diamond', spreadName: 'Diamond',
      date: today - 3*day, question: 'What is the next step in my work?',
      cards: [
        { cardId: 'creativity', position: 'Root' },
        { cardId: 'aloneness', position: 'Past' },
        { cardId: 'breakthrough', position: 'Future' },
        { cardId: 'inner-voice', position: 'Inner' },
        { cardId: 'completion', position: 'Outer' },
      ],
    },
    {
      id: 'r3', spreadId: 'relationship', spreadName: 'Relationship',
      date: today - 7*day, question: 'How can I be more present with M.?',
      cards: [
        { cardId: 'awareness', position: 'You' },
        { cardId: 'courage', position: 'Them' },
        { cardId: 'lovers', position: 'Between' },
        { cardId: 'innocence', position: 'The Invitation' },
      ],
    },
  ];
}

const TWEAKS = /*EDITMODE-BEGIN*/{
  "accentHue": 22,
  "cardBack": "zen-classic",
  "showHaptic": true,
  "fontPair": "source-serif"
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweak] = useTweaks(TWEAKS);
  const [readings, setReadings] = useState(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return seedReadings();
  });

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(readings)); } catch (e) {}
  }, [readings]);

  // Navigation: stack of screens
  const [stack, setStack] = useState([{ kind: 'tabs', tab: 'home' }]);
  const top = stack[stack.length - 1];

  function push(s) { setStack(prev => [...prev, s]); }
  function pop() { setStack(prev => prev.length > 1 ? prev.slice(0, -1) : prev); }
  function reset() { setStack([{ kind: 'tabs', tab: 'home' }]); }
  function setTab(tab) { setStack([{ kind: 'tabs', tab }]); }

  const todayCard = useMemo(() => {
    const seed = new Date().getDate() + new Date().getMonth();
    return window.OSHO_CARDS[seed % window.OSHO_CARDS.length];
  }, []);

  // Apply accent hue to root
  useEffect(() => {
    const h = tweaks.accentHue;
    document.documentElement.style.setProperty('--c-clay', `oklch(0.59 0.13 ${h})`);
    document.documentElement.style.setProperty('--c-clay-deep', `oklch(0.49 0.13 ${h})`);
    document.documentElement.style.setProperty('--c-clay-soft', `oklch(0.86 0.05 ${h})`);
    document.documentElement.style.setProperty('--c-clay-wash', `oklch(0.92 0.03 ${h})`);
  }, [tweaks.accentHue]);

  function renderTop() {
    if (top.kind === 'tabs') {
      switch (top.tab) {
        case 'home':
          return <HomeScreen
            todayCard={todayCard}
            recentReadings={readings}
            goSpread={(id) => push({ kind: 'spread-detail', spreadId: id })}
            goAllSpreads={() => setTab('spreads')}
            goCardOfDay={() => push({ kind: 'card-of-day' })}
            goJournal={() => setTab('journal')}
          />;
        case 'spreads':
          return <SpreadsScreen
            goBack={null}
            goSpread={(id) => push({ kind: 'spread-detail', spreadId: id })}
          />;
        case 'journal':
          return <JournalScreen
            goBack={null}
            readings={readings}
            onOpen={(r) => push({ kind: 'reading-view', reading: r })}
          />;
        case 'self':
          return <SelfScreen
            goBack={null}
            streak={3}
            totalReadings={readings.length}
            onOpenInstructions={() => push({ kind: 'instructions' })}
          />;
      }
    }

    if (top.kind === 'spread-detail') {
      const spread = window.OSHO_SPREADS.find(s => s.id === top.spreadId);
      return <SpreadDetailScreen
        spread={spread}
        goBack={pop}
        onBegin={(q) => push({ kind: 'shuffle', spreadId: top.spreadId, question: q })}
      />;
    }
    if (top.kind === 'shuffle') {
      const spread = window.OSHO_SPREADS.find(s => s.id === top.spreadId);
      return <ShuffleScreen
        spread={spread}
        question={top.question}
        goBack={pop}
        onReady={() => setStack(prev => [...prev.slice(0,-1), { kind: 'draw', spreadId: top.spreadId, question: top.question }])}
      />;
    }
    if (top.kind === 'draw') {
      const spread = window.OSHO_SPREADS.find(s => s.id === top.spreadId);
      return <DrawScreen
        spread={spread}
        question={top.question}
        goBack={pop}
        onComplete={(drawn) => setStack(prev => [...prev.slice(0,-2), {
          kind: 'reading', spreadId: top.spreadId, question: top.question, drawn
        }])}
      />;
    }
    if (top.kind === 'reading') {
      const spread = window.OSHO_SPREADS.find(s => s.id === top.spreadId);
      return <ReadingScreen
        spread={spread}
        question={top.question}
        drawn={top.drawn}
        goBack={pop}
        goHome={reset}
        onSave={() => {
          const newR = {
            id: 'r' + Date.now(),
            spreadId: top.spreadId,
            spreadName: spread.name,
            question: top.question,
            cards: top.drawn,
            date: Date.now(),
          };
          setReadings(rs => [newR, ...rs]);
          reset();
          setTab('journal');
        }}
      />;
    }
    if (top.kind === 'reading-view') {
      const spread = window.OSHO_SPREADS.find(s => s.id === top.reading.spreadId);
      return <ReadingScreen
        spread={spread}
        question={top.reading.question}
        drawn={top.reading.cards}
        goBack={pop}
        goHome={reset}
        onSave={() => pop()}
      />;
    }
    if (top.kind === 'card-of-day') {
      // Reuse Reading screen for card of the day
      return <ReadingScreen
        spread={window.OSHO_SPREADS[0]}
        question="What does today ask of me?"
        drawn={[{ cardId: todayCard.id, deckIdx: 0 }]}
        goBack={pop}
        goHome={reset}
        onSave={() => pop()}
      />;
    }
    if (top.kind === 'instructions') {
      return <InstructionsScreen goBack={pop}/>;
    }
    return null;
  }

  // Tab bar shows only on root tab screens
  const showTabBar = top.kind === 'tabs';

  // Status bar coloring — dark in shuffle/draw screens
  const darkStatus = (top.kind === 'shuffle' || top.kind === 'draw');

  return (
    <IOSDevice dark={darkStatus}>
      <div style={{
        position: 'absolute', inset: 0,
        background: darkStatus ? 'var(--c-zen-night)' : 'var(--c-canvas)',
        display: 'flex', flexDirection: 'column',
        paddingTop: 56, // leave room for absolute status bar/dynamic island
      }}>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
          {renderTop()}
        </div>
        {showTabBar && <TabBar tab={top.tab} setTab={setTab}/>}
      </div>

      <TweaksPanel title="Tweaks">
        <TweakSection title="Accent">
          <TweakSlider label="Hue" value={tweaks.accentHue} min={0} max={360} step={1}
            onChange={v => setTweak('accentHue', v)}/>
          <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
            {[
              { name: 'Clay (default)', h: 22 },
              { name: 'Saffron', h: 50 },
              { name: 'Forest', h: 145 },
              { name: 'Indigo', h: 260 },
              { name: 'Plum', h: 320 },
            ].map(p => (
              <button key={p.name} onClick={() => setTweak('accentHue', p.h)} style={{
                width: 28, height: 28, borderRadius: '50%',
                background: `oklch(0.59 0.13 ${p.h})`, border: '0.5px solid rgba(0,0,0,0.1)',
                cursor: 'pointer', padding: 0,
                outline: tweaks.accentHue === p.h ? '2px solid #1F1B16' : 'none',
                outlineOffset: 2,
              }} title={p.name}/>
            ))}
          </div>
        </TweakSection>
        <TweakSection title="Card design">
          <TweakRadio label="Card back" value={tweaks.cardBack}
            onChange={v => setTweak('cardBack', v)}
            options={[{value:'zen-classic',label:'Zen'},{value:'sigil',label:'Sigil'},{value:'plain',label:'Plain'}]}/>
        </TweakSection>
        <TweakSection title="Behavior">
          <TweakToggle label="Haptics" checked={tweaks.showHaptic} onChange={v => setTweak('showHaptic', v)}/>
        </TweakSection>
      </TweaksPanel>
    </IOSDevice>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
